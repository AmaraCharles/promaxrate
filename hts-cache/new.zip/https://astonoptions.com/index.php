


      <!DOCTYPE php>
<php lang="en">

<head>
    
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="description" content="Aston Options - Your Trusted Broker for Financial Success">
    <meta name="keywords" content="Aston Options, brokers, financial, investments, trading">
    <meta name="author" content="Aston Options">

    <!-- Open Graph / Facebook -->
    

    <!-- Favicon -->
<link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon">

  <link rel="apple-touch-icon" href="https://astonoptions.com/assets/images/copy.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Aston Optionsl">
    <!-- Google / Search Engine Tags -->
    <meta itemprop="name" content="Aston Options">
    <meta itemprop="description" content="Your Trusted Broker for Financial Success">
    <meta itemprop="image" content="https://astonoptions.com/assets/images/copy.png">
    <!-- Facebook Meta Tags -->
    <meta property="og:title" content="Aston Options" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://astonoptions.com" />
    <meta property="og:image" content="https://astonoptions.com/assets/images/copy.png" />
    <meta property="og:description" content="Your Trusted Broker for Financial Success" />
    <meta property="og:site_name" content="Aston Optionsl" />

    <title>Aston Options - Your Trusted Broker</title>




<!-- Fav Icon -->

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="assets/css/font-awesome-all.css" rel="stylesheet">
<link href="assets/css/flaticon.css" rel="stylesheet">
<link href="assets/css/owl.css" rel="stylesheet">
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="assets/css/animate.css" rel="stylesheet">
<link href="assets/css/nice-select.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/responsive.css" rel="stylesheet">

</head>
<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '59ba79d2fc419942ea29a8fbc1af2f46d3be4b3a';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>

<!-- page wrapper -->
<body>

    <div class="boxed_wrapper">
 <!-- preloader -->
  <div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                        
                           
                        </div>
                    </div>  
                </div>
            </div>
        </div>
        <!-- preloader end -->


     


        <!-- main header -->
        <header class="main-header">
            <!-- header-top -->
            <div class="header-top">
                <div class="outer-container">
                   
                  <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">

  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "proName": "FOREXCOM:SPXUSD",
      "title": "S&P 500"
    },
    {
      "proName": "FOREXCOM:NSXUSD",
      "title": "US 100"
    },
    {
      "proName": "FX_IDC:EURUSD",
      "title": "EUR to USD"
    },
    {
      "proName": "BITSTAMP:BTCUSD",
      "title": "Bitcoin"
    },
    {
      "proName": "BITSTAMP:ETHUSD",
      "title": "Ethereum"
    }
  ],
  "showSymbolLogo": true,
  "colorTheme": "dark",
  "isTransparent": false,
  "displayMode": "adaptive",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="index.php"><img src="assets/images/logo.png" alt="Aston" style="width:158px;height:42px"></a></figure>
                            </div>
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                                                                         <div class="btn-box "><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one text-small  d-lg-none d-md-none"><span>Register</span></a></div>

                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li ><a href="index.php">Home</a></li>  
                                        <li ><a href="market.php">Markets</a></li>
                                        <li class="dropdown"><a href="#">Mirror Trades</a>
                                            <ul>
                                                
                                                <li><a href="forex.php">Forex</a></li>
                                                <li><a href="copy.php">Copy Trading</a></li>
                                                <li><a href="options.php">Option Trading</a></li>
                                                <li><a href="stocks.php">Stocks Trading</a></li>
                                           
                                            </ul>
                                        </li> 
                                        <li class="dropdown"><a href="#">Planning Services</a>
                                            <ul>
                                            <li><a href="estate.php">Estate Planning</a></li>
                                            <li><a href="retirement.php">Retirement Planning</a></li>
                                            <li><a href="financial.php">Financial Planning</a></li>
                                            <li><a href="privatewealth.php">Private Wealth</a></li>
                                            </ul>
                                        </li> 
                                        <li ><a href="about.php">About Us</a></li>  
                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!-- <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div> -->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a href="https://app.astonoptions.com/user/login" >Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            <div class="btn-box"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one "><span>Register</span></a></div>
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="index.php"><img src="assets/images/logo.png" alt="" style="width:158px;height:42px"></a></figure>
                            </div>
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!-- <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div> -->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a  href="https://app.astonoptions.com/user/login">Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            <div class="btn-box"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Open an A/c</span></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>
            
            <nav class="menu-box">
                <div class="nav-logo"><a href="index.php"><img src="assets/images/logo.png" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                                                <li><a href="mailto:info@astonoptions.com">info@astonoptions.com</a></li>

                        <!-- <li>Chicago 12, Melborne City, USA</li>
                        <li><a href="tel:+8801682648101">+88 01682648101</a></li> -->
                        <li><a href="mailto:support@astonoptions.com">support@astonoptions.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    

                </div>
            </nav>
        </div><!-- End Mobile Menu -->

        <!-- banner-section -->
        <section class="banner-section">
            <div class="banner-carousel owl-theme owl-carousel nav-style-one">
                <div class="slide-item">
                    <div class="bg-layer" style="background-image:url(assets/images/banner/banner-1.jpg)"></div>
                    <div class="image-layer" style="background-image:url(assets/images/banner/banner-2.jpg)"></div>
                    <div class="large-container">
                        <div class="content-box">
                            <h2><span>Account</span> <br />that Suits Your Trading Style</h2>
                            <p>We are here to simplify the process and empower you to make informed decisions about your financial future</p>
                            <div class="btn-box">
                                <a href="https://app.astonoptions.com/user/register" class="theme-btn btn-two"><span>Join Now</span></a>
                            </div>
                            <div class="highlights-box">
                                <div class="single-item">
                                    <span class="count-text">01.</span>
                                    <h3>Forex</h3>
                                    <div class="text">As a leading online brokerage platform, we are dedicated to providing you with the tools, resources, and expert guidance you need to achieve your financial goals.</div>
                                    <a href="market.php"><span>Read More</span></a>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
                <div class="slide-item">
                    <div class="bg-layer" style="background-image:url(assets/images/banner/banner-1.jpg)"></div>
                    <div class="image-layer" style="background-image:url(assets/images/banner/banner-3.jpg)"></div>
                    <div class="large-container">
                        <div class="content-box">
                            <h2>Best <span>Tools</span> For Sucessful Trading</h2>
                            <p>We provide a wide range of options to suit your unique trading preferences and risk tolerance.</p>
                            <div class="btn-box">
                                <a href="https://app.astonoptions.com/user/register" class="theme-btn btn-two"><span>Join Now</span></a>
                            </div>
                            <div class="highlights-box">
                                <div class="single-item">
                                    <span class="count-text">02.</span>
                                    <h3>Gold&nbsp;&&nbsp;Silver</h3>
                                    <div class="text">Trading in precious metals, particularly gold and silver, has been a time-honored strategy for wealth preservation and diversification.</div>
                                    <a href="market.php"><span>Read More</span></a>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
                <div class="slide-item">
                    <div class="bg-layer" style="background-image:url(assets/images/banner/banner-1.jpg)"></div>
                    <div class="image-layer" style="background-image:url(assets/images/banner/banner-4.jpg)"></div>
                    <div class="large-container">
                        <div class="content-box">
                            <h2>Complete <span>Forex</span> Trading Experience</h2>
                            <p>The foreign exchange (Forex) market is the largest and most liquid financial market globally. </p>
                            <div class="btn-box">
                                <a href="https://app.astonoptions.com/user/register" class="theme-btn btn-two"><span>Try Free Demo</span></a>
                            </div>
                            <div class="highlights-box">
                                <div class="single-item">
                                    <span class="count-text">03.</span>
                                    <h3>Platinum</h3>
                                    <div class="text">These metals are often considered safe-haven assets, with their value influenced by geopolitical events, economic uncertainty, and inflation concerns.</div>
                                    <a href="market.php"><span>Read More</span></a>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
            <!-- <ul class="social-links clearfix">
                <li><a href="index.php">Instagram<i class="fa-brands fa-instagram"></i></a></li>
                <li><a href="index.php">Twitter<i class="fa-brands fa-square-twitter"></i></a></li>
                <li><a href="index.php">Facebook<i class="fa-brands fa-facebook"></i></a></li>
            </ul> -->
        </section>
        <!-- banner-section end -->


        <!-- about-section -->
        <section class="about-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <figure class="image-box"><img src="assets/images/resource/about-1.jpg" alt=""></figure>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content-box">
                            <div class="sec-title">
                                <span class="sub-title">About Aston Options</span>
                                <h2>In a Fast Moving <br />Market Choose a <span>Stable Broker</span></h2>
                            </div>
                            <div class="inner-box">
                                <p>At Aston Options, we understand that navigating the complex world of finance can be a daunting task. That's why we are here to simplify the process and empower you to make informed decisions about your financial future. As a leading online brokerage platform, we are dedicated to providing you with the tools, resources, and expert guidance you need to achieve your financial goals.</p>
                                <div class="quote-box"><h4>Everything you need to trade Forex in one place</h4></div>
                                <!-- <p>All forms of trading style,</p> -->
                                <ul class="list-item clearfix">
                                    <li>Scalper</li>
                                    <li>Day Trader</li>
                                    <li>Position Trader</li>
                                    <li>The Swing Trader</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about-section end -->


        <!-- trading-section -->
        <section class="trading-section sec-pad">
            <div class="pattern-layer">
                <div class="pattern-1" style="background-image: url(assets/images/shape/shape-1.png);"></div>
                <div class="pattern-2" style="background-image: url(assets/images/shape/shape-2.png);"></div>
            </div>
            <div class="auto-container">
                <div class="sec-title centred light">
                    <span class="sub-title"> The Ultimate Gateway to Trading Success</span>
                    <h2>Mirror  <span>Trades</span> </h2>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-6 col-sm-12 trading-block">
                        <div class="trading-block-one wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-7.png" alt=""></div>
                                <div class="overlay-icon"><img src="assets/images/icons/icon-8.png" alt=""></div>
                                <div class="text">
                                    <h3><a href="forex.php">Forex</a></h3>
                                    <p>In Forex (foreign exchange) trading, currencies are traded in pairs, reflecting the relative value of one currency against another</p>
                                </div>
                                <div class="lower-text"><h6><span>*</span> Forex Trading</h6></div>
                                <div class="link-box"><a href="forex.php"><span>More</span></a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 trading-block">
                        <div class="trading-block-one wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-9.png" alt=""></div>
                                <div class="overlay-icon"><img src="assets/images/icons/icon-10.png" alt=""></div>
                                <div class="text">
                                    <h3><a href="stocks.php">Stocks Trading</a></h3>
                                    <p>Successful stock trading often requires a combination of fundamental and technical analysis. </p>
                                </div>
                                <div class="lower-text"><h6><span>*</span> Stocks Trading</h6></div>
                                <div class="link-box"><a href="stocks.php"><span>More</span></a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 trading-block">
                        <div class="trading-block-one wow fadeInUp animated" data-wow-delay="600ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-11.png" alt=""></div>
                                <div class="overlay-icon"><img src="assets/images/icons/icon-12.png" alt=""></div>
                                <div class="text">
                                    <h3><a href="options.php">Options<br />Trading?</a></h3>
                                    <p>Options are financial instruments that derive their value from an underlying asset, often stocks.  </p>
                                </div>
                                <div class="lower-text"><h6><span>*</span> Options Trading</h6></div>
                                <div class="link-box"><a href="options.php"><span>More</span></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- trading-section end -->



       





        <section class="account-style-two sec-pad">
            <div class="auto-container">
                <div class="sec-title centred">
                    <span class="sub-title">Account Types</span>
                    <h2>Aston Options Trading <span>Accounts</span></h2>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-6 col-sm-12 account-block">
                        <div class="account-block-two wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="upper-box centred">
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-13.png);"></div>
                                    <h3>Standard a/c</h3>
                                    <!-- <p>Beguiled demoralized by charms non</p> -->
                                    <div class="icon-box"><img src="assets/images/icons/icon-37.png" alt=""></div>
                                </div>
                                <div class="content-box">
                                    <ul class="list-item clearfix">
                                        <li>Minimum Deposit <span>$3000</span></li>
                                        <li>Leverage <span>Up to 1:1000</span></li>
                                        <li>Order Volume <span>0.01 - 500 lots</span></li>
                                        <li>Spread <span>Fixed from 3 pips</span></li>
                                        <li>Commission <span>10%</span></li>
                                    </ul>
                                </div>
                                <div class="lower-box">
                                    <div class="link-box"><a href="https://app.astonoptions.com/user/register"><span>Open Your Account</span></a></div>
                                    <!--<div class="more-link"><a href="https://app.astonoptions.com/user/register">More Info</a></div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 account-block">
                        <div class="account-block-two wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="recommended-box">
                                <h6>Most Recommended</h6>
                            </div>
                            <div class="inner-box">
                                <div class="upper-box centred">
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-13.png);"></div>
                                    <h3>Commission a/c</h3>
                                    <!-- <p>Case are perfectly simple free easy </p> -->
                                    <div class="icon-box"><img src="assets/images/icons/icon-38.png" alt=""></div>
                                </div>
                                <div class="content-box">
                                    <ul class="list-item clearfix">
                                        <li>Minimum Deposit <span>$5000</span></li>
                                        <li>Leverage <span>Up to 1:2000</span></li>
                                        <li>Order Volume <span>0.01 - 800 lots</span></li>
                                        <li>Spread <span>Fixed from 2 pips</span></li>
                                         <li>Commission <span>10%</span></li>

                                    </ul>
                                </div>
                                <div class="lower-box">
                                    <div class="link-box"><a href="https://app.astonoptions.com/user/register"><span>Open Your Account</span></a></div>
                                    <!--<div class="more-link"><a href="https://app.astonoptions.com/user/register">More Info</a></div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 account-block">
                        <div class="account-block-two wow fadeInUp animated" data-wow-delay="600ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="upper-box centred">
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-13.png);"></div>
                                    <h3>Stp Pro a/c</h3>
                                    <!-- <p>The claims off duty or the obligations</p> -->
                                    <div class="icon-box"><img src="assets/images/icons/icon-39.png" alt=""></div>
                                </div>
                                <div class="content-box">
                                    <ul class="list-item clearfix">
                                        <li>Initial Deposit <span>$10000</span></li>
                                        <li>Leverage <span>Up to 1:3000</span></li>
                                        <li>Order Volume <span>0.01 - 1000 lots</span></li>
                                        <li>Spread <span>Fixed from 1 pip</span></li>
                                        <li>Commission <span>10%</span></li>

                                    </ul>
                                </div>
                                <div class="lower-box">
                                    <div class="link-box"><a href="https://app.astonoptions.com/user/register"><span>Open Your Account</span></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section class="markets-style-two">
            <div class="auto-container">
                <div class="inner-container">
                    <div class="shape" style="background-image: url(assets/images/shape/shape-36.png);"></div>
                    <div class="row clearfix">
                        <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                            <div class="content-box">
                                <div class="sec-title light">
                                    <span class="sub-title">Trade Forex</span>
                                    <h2>Forex Markets <br />with Competitive Prices</h2>
                                </div>
                                <div class="text-box">
                                    <h4>Trade Over 140 FX Pairs</h4>
                                    <p> Major pairs like EUR/USD and GBP/USD dominate the market, while exotic pairs involve currencies from smaller economies. The Forex market is known for its liquidity, providing ample opportunities for traders to engage in transactions.</p>
                                </div>
                                <div class="btn-inner">
                                    <div class="btn-box"><a href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Get Started</span></a></div>
                                    <!--<div class="link-box">-->
                                    <!--    <a href="https://app.astonoptions.com/user/register"><span>/span></a>-->
                                    <!--</div>-->
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                            <figure class="image-box"><img src="assets/images/resource/market-7.jpg" alt=""></figure>
                        </div>
                    </div>
                </div>
            </div>
        </section>



        <!-- account-section -->
        <section class="account-section bg-color-1 mb-0">
            <div class="auto-container">
                <div class="sec-title centred">
                    <span class="sub-title"> Achieve Your Goals</span>
                    <h2>Planning  <span>Services</span></h2>
                </div>
                <div class="three-item-carousel owl-carousel owl-theme owl-dots-none nav-style-one">
                    <div class="account-block-one">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><img src="assets/images/resource/account-1.jpg" alt=""></figure>
                                <div class="title-text">
                                    <h3><a href="privatewealth.php">Private Wealth</a></h3>
                                    <div class="icon-box"><img src="assets/images/icons/icon-13.png" alt=""></div>
                                </div>
                            </div>
                            <div class="lower-content">
                                <div class="text-box">
                                    <p>Identify short-term and long-term financial objectives.</p>
                                </div>
                                <div class="link-box">
                                    <a href="https://app.astonoptions.com/user/register"><span>Open Your Account</span></a>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="account-block-one">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><img src="assets/images/resource/account-2.jpg" alt=""></figure>
                                <div class="title-text">
                                    <h3><a href="retirement.php">Retirement Planning</a></h3>
                                    <div class="icon-box"><img src="assets/images/icons/icon-14.png" alt=""></div>
                                </div>
                            </div>
                            <div class="lower-content">
                                <div class="text-box">
                                    <p>Estimate retirement expenses and income needs.</p>
                                </div>
                                <div class="link-box">
                                    <a href="https://app.astonoptions.com/user/register"><span>Open Your Account</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="account-block-one">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><img src="assets/images/resource/account-3.jpg" alt=""></figure>
                                <div class="title-text">
                                    <h3><a href="financial.php">Financial Planning</a></h3>
                                    <div class="icon-box"><img src="assets/images/icons/icon-15.png" alt=""></div>
                                </div>
                            </div>
                            <div class="lower-content">
                                <div class="text-box">
                                    <p>Budgeting, savings strategies, investment planning, tax planning, and risk management</p>
                                </div>
                                <div class="link-box">
                                    <a href="https://app.astonoptions.com/user/register"><span>Open Your Account</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- account-section end -->


    


        <!-- pricing-section -->
        <section class="pricing-section sec-pad">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-3.png);"></div>
            <div class="auto-container">
                <div class="sec-title centred">
                    <span class="sub-title">Forex Trading</span>
                    <h2>Top <span>Pricing</span> List in Market</h2>
                </div>
                <div class="tabs-box">
                    
                    <div class="tabs-content">
                        <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">

  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-market-quotes.js" async>
  {
  "width": "100%",
  "height": "100%",
  "symbolsGroups": [
    {
      "name": "Indices",
      "originalName": "Indices",
      "symbols": [
        {
          "name": "FOREXCOM:SPXUSD",
          "displayName": "S&P 500"
        },
        {
          "name": "FOREXCOM:NSXUSD",
          "displayName": "US 100"
        },
        {
          "name": "FOREXCOM:DJI",
          "displayName": "Dow 30"
        },
        {
          "name": "INDEX:NKY",
          "displayName": "Nikkei 225"
        },
        {
          "name": "INDEX:DEU40",
          "displayName": "DAX Index"
        },
        {
          "name": "FOREXCOM:UKXGBP",
          "displayName": "UK 100"
        }
      ]
    },
    {
      "name": "Futures",
      "originalName": "Futures",
      "symbols": [
        {
          "name": "CME_MINI:ES1!",
          "displayName": "S&P 500"
        },
        {
          "name": "CME:6E1!",
          "displayName": "Euro"
        },
        {
          "name": "COMEX:GC1!",
          "displayName": "Gold"
        },
        {
          "name": "NYMEX:CL1!",
          "displayName": "WTI Crude Oil"
        },
        {
          "name": "NYMEX:NG1!",
          "displayName": "Gas"
        },
        {
          "name": "CBOT:ZC1!",
          "displayName": "Corn"
        }
      ]
    },
    {
      "name": "Bonds",
      "originalName": "Bonds",
      "symbols": [
        {
          "name": "CBOT:ZB1!",
          "displayName": "T-Bond"
        },
        {
          "name": "CBOT:UB1!",
          "displayName": "Ultra T-Bond"
        },
        {
          "name": "EUREX:FGBL1!",
          "displayName": "Euro Bund"
        },
        {
          "name": "EUREX:FBTP1!",
          "displayName": "Euro BTP"
        },
        {
          "name": "EUREX:FGBM1!",
          "displayName": "Euro BOBL"
        }
      ]
    },
    {
      "name": "Forex",
      "originalName": "Forex",
      "symbols": [
        {
          "name": "FX:EURUSD",
          "displayName": "EUR to USD"
        },
        {
          "name": "FX:GBPUSD",
          "displayName": "GBP to USD"
        },
        {
          "name": "FX:USDJPY",
          "displayName": "USD to JPY"
        },
        {
          "name": "FX:USDCHF",
          "displayName": "USD to CHF"
        },
        {
          "name": "FX:AUDUSD",
          "displayName": "AUD to USD"
        },
        {
          "name": "FX:USDCAD",
          "displayName": "USD to CAD"
        }
      ]
    }
  ],
  "showSymbolLogo": true,
  "colorTheme": "light",
  "isTransparent": false,
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
                    </div>
                </div>
                <!-- <div class="link-box centred">
                    <a href="index.php"><span>See More</span></a>
                </div> -->
            </div>
        </section>
        <!-- pricing-section end -->


        <!-- tools-section -->
        <!-- <section class="tools-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <figure class="image-box"><img src="assets/images/resource/tools-1.jpg" alt=""></figure>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content-box">
                            <div class="sec-title light">
                                <span class="sub-title">Trading Tools</span>
                                <h2><span>Tools</span> for Every Trader</h2>
                            </div>
                            <div class="tools-carousel owl-carousel owl-theme owl-dots-none">
                                <div class="tools-block-one">
                                    <div class="inner-box">
                                        <div class="overlay-title">
                                            <span class="count-text">02</span>
                                            <h3>Margin Calulator</h3>
                                        </div>
                                        <div class="overlay-title style-two">
                                            <span class="count-text">03</span>
                                            <h3>Pip Value Calculator</h3>
                                        </div>
                                        <div class="icon-box">
                                            <div class="icon"><img src="assets/images/icons/icon-16.png" alt=""></div>
                                        </div>
                                        <div class="title-box">
                                            <h3><a href="index.php">Free Currency Converter</a></h3>
                                            <span class="count-text">01</span>
                                        </div>
                                        <div class="text-box">
                                            <p>Error voluptatem accusantium dolor emque laudantium totam aperio non inventore veritatis quasi.</p>
                                        </div>
                                        <div class="link-box">
                                            <a href="index.php"><span>Use Our Tool</span></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="tools-block-one">
                                    <div class="inner-box">
                                        <div class="overlay-title">
                                            <span class="count-text">03</span>
                                            <h3>Pip Value Calculator</h3>
                                        </div>
                                        <div class="overlay-title style-two">
                                            <span class="count-text">01</span>
                                            <h3>Free Currency Converter</h3>
                                        </div>
                                        <div class="icon-box">
                                            <div class="icon"><img src="assets/images/icons/icon-16.png" alt=""></div>
                                        </div>
                                        <div class="title-box">
                                            <h3><a href="index.php">Margin Calulator</a></h3>
                                            <span class="count-text">02</span>
                                        </div>
                                        <div class="text-box">
                                            <p>Error voluptatem accusantium dolor emque laudantium totam aperio non inventore veritatis quasi.</p>
                                        </div>
                                        <div class="link-box">
                                            <a href="index.php"><span>Use Our Tool</span></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="tools-block-one">
                                    <div class="inner-box">
                                        <div class="overlay-title">
                                            <span class="count-text">01</span>
                                            <h3>Free Currency Converter</h3>
                                        </div>
                                        <div class="overlay-title style-two">
                                            <span class="count-text">02</span>
                                            <h3>Margin Calulator</h3>
                                        </div>
                                        <div class="icon-box">
                                            <div class="icon"><img src="assets/images/icons/icon-16.png" alt=""></div>
                                        </div>
                                        <div class="title-box">
                                            <h3><a href="index.php">Pip Value Calculator</a></h3>
                                            <span class="count-text">03</span>
                                        </div>
                                        <div class="text-box">
                                            <p>Error voluptatem accusantium dolor emque laudantium totam aperio non inventore veritatis quasi.</p>
                                        </div>
                                        <div class="link-box">
                                            <a href="index.php"><span>Use Our Tool</span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- tools-section end -->


        <!-- working-section -->
        <section class="working-section sec-pad centred">
            <div class="auto-container">
                <div class="sec-title">
                    <span class="sub-title">How it’s Work</span>
                    <h2><span>Start Trading</span> on Your Terms</h2>
                </div>
                <div class="content-inner clearfix">
                    <div class="working-block-one">
                        <div class="inner-box">
                            <div class="static-content">
                                <div class="icon-box"><img src="assets/images/icons/icon-17.png" alt=""></div>
                                <h4>Open <br />your account</h4>
                                <p>Create an account with us</p>
                            </div>
                            <div class="overlay-content">
                                <h4>Open <br />your account</h4>
                                <!-- <p>Beguiled demoralized all Temporibus aute quibusda aut officiis debitis.</p> -->
                            </div>
                            <span class="count-text">Step 01</span>
                        </div>
                        <div class="link"><a href="index.php"><i class="flaticon-right-arrow"></i></a></div>
                    </div>
                    <div class="working-block-one">
                        <div class="inner-box">
                            <div class="static-content">
                                <div class="icon-box"><img src="assets/images/icons/icon-18.png" alt=""></div>
                                <h4>Make <br />Deposit</h4>
                                <!-- <p>Minus id maxime placeat...</p> -->
                            </div>
                            <div class="overlay-content">
                                <h4>Make <br />Deposit</h4>
                                <!-- <p>Minus id maxime placeat Temporibus aute quibusda aut officiis debitis.</p> -->
                            </div>
                            <span class="count-text">Step 02</span>
                        </div>
                        <div class="link"><a href="index.php"><i class="flaticon-right-arrow"></i></a></div>
                    </div>
                    <div class="working-block-one">
                        <div class="inner-box">
                            <div class="static-content">
                                <div class="icon-box"><img src="assets/images/icons/icon-19.png" alt=""></div>
                                <h4>Select a Trader<br /> to Copy</h4>
                                <!-- <p>Itaque earu rerum tenetur...</p> -->
                            </div>
                            <div class="overlay-content">
                                <h4>Select a Trader <br />to Copy</h4>
                                <!-- <p>Itaque earu rerum tenetur Temporibus aute quibusda aut officiis debitis.</p> -->
                            </div>
                            <span class="count-text">Step 03</span>
                        </div>
                        <div class="link"><a href="index.php"><i class="flaticon-right-arrow"></i></a></div>
                    </div>
                    <div class="working-block-one">
                        <div class="inner-box">
                            <div class="static-content">
                                <div class="icon-box"><img src="assets/images/icons/icon-20.png" alt=""></div>
                                <h4>Relax and <br />& make money</h4>
                                <!-- <p>perferen doloribus asperio...</p> -->
                            </div>
                            <div class="overlay-content">
                                <h4>Relax and <br />& make money</h4>
                                <!-- <p>perferen doloribus asperio Temporibus aute quibusda aut officiis debitis.</p> -->
                            </div>
                            <span class="count-text">Step 04</span>
                        </div>
                    </div>
                </div>
                <div class="lower-content">
                    <p>Everything you need to trade Forex in one place.</p>
                  
                </div>
            </div>
        </section>
        <!-- working-section end -->


        <!-- chooseus-section -->
        <section class="chooseus-section">
            <div class="bg-layer" style="background-image: url(assets/images/background/chooseus-bg.jpg);"></div>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-xl-8 col-lg-12 col-md-12 content-column">
                        <div class="content-box">
                            <div class="sec-title light">
                                <span class="sub-title"></span>
                                <h2>Why <span>Choose Us</span></h2>
                            </div>
                            <div class="row clearfix">
                                <div class="col-lg-6 col-md-6 col-sm-12 chooseus-block">
                                    <div class="chooseus-block-one">
                                        <div class="inner-box">
                                            <div class="shape">
                                                <div class="shape-1" style="background-image: url(assets/images/shape/shape-4.png);"></div>
                                                <div class="shape-2" style="background-image: url(assets/images/shape/shape-5.png);"></div>
                                                <div class="shape-3" style="background-image: url(assets/images/shape/shape-6.png);"></div>
                                            </div>
                                            <h3><a href="index.php">Friendly & Expert</a></h3>
                                            <p>We have seasoned expert in field of trading analysis and they are at your disposal</p>
                                            <div class="icon-box"><img src="assets/images/icons/icon-21.png" alt=""></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 chooseus-block">
                                    <div class="chooseus-block-one">
                                        <div class="inner-box">
                                            <div class="shape">
                                                <div class="shape-1" style="background-image: url(assets/images/shape/shape-4.png);"></div>
                                                <div class="shape-2" style="background-image: url(assets/images/shape/shape-5.png);"></div>
                                                <div class="shape-3" style="background-image: url(assets/images/shape/shape-6.png);"></div>
                                            </div>
                                            <h3><a href="index.php">24/7 Support</a></h3>
                                            <p>Our support team are always available to respond to your query</p>
                                            <div class="icon-box"><img src="assets/images/icons/icon-22.png" alt=""></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 chooseus-block">
                                    <div class="chooseus-block-one">
                                        <div class="inner-box">
                                            <div class="shape">
                                                <div class="shape-1" style="background-image: url(assets/images/shape/shape-4.png);"></div>
                                                <div class="shape-2" style="background-image: url(assets/images/shape/shape-5.png);"></div>
                                                <div class="shape-3" style="background-image: url(assets/images/shape/shape-6.png);"></div>
                                            </div>
                                            <h3><a href="index.php">Demo account</a></h3>
                                            <p>You are not sure yet? we have a demo account to boost your confidence</p>
                                            <div class="icon-box"><img src="assets/images/icons/icon-23.png" alt=""></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 chooseus-block">
                                    <div class="chooseus-block-one">
                                        <div class="inner-box">
                                            <div class="shape">
                                                <div class="shape-1" style="background-image: url(assets/images/shape/shape-4.png);"></div>
                                                <div class="shape-2" style="background-image: url(assets/images/shape/shape-5.png);"></div>
                                                <div class="shape-3" style="background-image: url(assets/images/shape/shape-6.png);"></div>
                                            </div>
                                            <h3><a href="index.php">Award winner</a></h3>
                                            <p>We are pace setters in this industries an have lots of award  in that regard</p>
                                            <div class="icon-box"><img src="assets/images/icons/icon-24.png" alt=""></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- chooseus-section end -->


<!-- Copy Trading-->

        <section class="platform-section sec-pad">
            <div class="auto-container">
                <div class="row align-items-center">
                      <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div class="image-box">
                            <div class="image-shape">
                                <div class="shape-1"></div>
                                <div class="shape-2 rotate-me" style="background-image: url(assets/images/shape/shape-14.png);"></div>
                            </div>
                            <figure class="image"><img src="assets/images/copy.png" alt=""></figure>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content-box">
                            <div class="sec-title">
                                <span class="sub-title">Copy Trading</span>
                                <h2>Copy <span>Trades</span> of Experienced Traders</h2>
                            </div>
                            <div class="text-box">
                                <p>Copy trading opens up the world of financial markets to individuals who may lack the time, knowledge, or experience to trade independently.</p>
                            </div>
                            <ul class="list-item clearfix">
                                <li><h4>Accessibility<span>01</span></h4></li>
                                <li><h4>Diversification<span>02</span></h4></li>
                                <li><h4>Time Efficiency<span>03</span></h4></li>
                            </ul>
                            <div class="lower-box">
                                <div class="btn-box">
                                    <a href="copy.php" class="theme-btn"><span>Check It Out</span></a>
                                </div>
                                 <div class="btn-box">
                                    <a href="expert-traders.php" class="theme-btn" style="background-color:#FE5924"><span>See Expert Traders</span></a>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                  
                </div>
            </div>
        </section>

<!--Copy Trading Ends-->


        <!-- Blog-section -->
        <!--<section class="news-section sec-pad">-->
        <!--    <div class="auto-container">-->
        <!--        <div class="sec-title centred">-->
        <!--            <span class="sub-title">News & Updates</span>-->
        <!--            <h2>Recent Post From <span>Our Blog</span></h2>-->
        <!--        </div>-->
        <!--        <div class="row clearfix">-->
        <!--            <div class="col-lg-4 col-md-6 col-sm-12 news-block">-->
        <!--                <div class="news-block-one wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">-->
        <!--                    <div class="inner-box">-->
        <!--                        <div class="image-box">-->
        <!--                            <figure class="image"><a href="blog-details.php"><img src="assets/images/news/news-1.jpg" alt=""></a></figure>-->
        <!--                            <span class="post-date">24 Dec</span>-->
        <!--                        </div>-->
        <!--                        <div class="lower-content">-->
        <!--                            <h3><a href="blog-details.php">Best FTSE 250 shares to buy in February 2023</a></h3>-->
        <!--                            <p>Error sit voluptatem accusantium doloremque...</p>-->
        <!--                            <div class="author-box">-->
        <!--                                <figure class="author-thumb"><img src="assets/images/news/author-1.jpg" alt=""></figure>-->
        <!--                                <h6>Trade Ideas</h6>-->
        <!--                                <ul class="post-info clearfix">-->
        <!--                                    <li><span>By</span> <a href="blog-details.php">Justin Langer</a></li>-->
        <!--                                    <li><span>To</span> 2 Mins Read</li>-->
        <!--                                </ul>-->
        <!--                            </div>-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--            <div class="col-lg-4 col-md-6 col-sm-12 news-block">-->
        <!--                <div class="news-block-one wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms">-->
        <!--                    <div class="inner-box">-->
        <!--                        <div class="image-box">-->
        <!--                            <figure class="image"><a href="blog-details.php"><img src="assets/images/news/news-2.jpg" alt=""></a></figure>-->
        <!--                            <span class="post-date">16 Dec</span>-->
        <!--                        </div>-->
        <!--                        <div class="lower-content">-->
        <!--                            <h3><a href="blog-details.php">Fixed vs floating exchange rates main differences</a></h3>-->
        <!--                            <p>Rerum facilis est et expedita distinctio libero...</p>-->
        <!--                            <div class="author-box">-->
        <!--                                <figure class="author-thumb"><img src="assets/images/news/author-1.jpg" alt=""></figure>-->
        <!--                                <h6>Economic</h6>-->
        <!--                                <ul class="post-info clearfix">-->
        <!--                                    <li><span>By</span> <a href="blog-details.php">Mylah Sophia</a></li>-->
        <!--                                    <li><span>To</span> 3 Mins Read</li>-->
        <!--                                </ul>-->
        <!--                            </div>-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--            <div class="col-lg-4 col-md-6 col-sm-12 news-block">-->
        <!--                <div class="news-block-one wow fadeInUp animated" data-wow-delay="600ms" data-wow-duration="1500ms">-->
        <!--                    <div class="inner-box">-->
        <!--                        <div class="image-box">-->
        <!--                            <figure class="image"><a href="blog-details.php"><img src="assets/images/news/news-3.jpg" alt=""></a></figure>-->
        <!--                            <span class="post-date">30 Nov</span>-->
        <!--                        </div>-->
        <!--                        <div class="lower-content">-->
        <!--                            <h3><a href="blog-details.php">Surprise move with widening of yield curve control band</a></h3>-->
        <!--                            <p>Temporibus autem quibusdam et aut debitis ...</p>-->
        <!--                            <div class="author-box">-->
        <!--                                <figure class="author-thumb"><img src="assets/images/news/author-1.jpg" alt=""></figure>-->
        <!--                                <h6>Updates</h6>-->
        <!--                                <ul class="post-info clearfix">-->
        <!--                                    <li><span>By</span> <a href="blog-details.php">Michael Rhys</a></li>-->
        <!--                                    <li><span>To</span> 2 Mins Read</li>-->
        <!--                                </ul>-->
        <!--                            </div>-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</section>-->
        <!-- Blog-section end -->


        <!-- apps-section -->
        <!-- <section class="apps-section bg-color-1">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-7.png);"></div>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div class="image-box">
                            <figure class="image"><img src="assets/images/resource/apps-1.jpg" alt=""></figure>
                            <div class="image-content">
                                <div class="text-box">
                                    <h2>4.7<span>Million +</span></h2>
                                    <p>Installation</p>
                                </div>
                                <ul class="rating clearfix">
                                    <li>4.96</li>
                                    <li><i class="flaticon-star"></i></li>
                                    <li><i class="flaticon-star"></i></li>
                                    <li><i class="flaticon-star"></i></li>
                                    <li><i class="flaticon-star"></i></li>
                                    <li><i class="flaticon-star"></i></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content-box">
                            <div class="sec-title">
                                <span class="sub-title">Mobile App</span>
                                <h2>Gives  a Platform to <br />Trade from <span>Anywhere</span> <br />in The World</h2>
                            </div>
                            <div class="text-box">
                                <p>Minus id quod maxime place at facere possimus, omnis voluptas assu- menda omnis dolors repellendus tempor.</p>
                            </div>
                            <div class="inner-box">
                                <div class="single-item">
                                    <div class="icon-box"><img src="assets/images/icons/icon-25.png" alt=""></div>
                                    <h3>Market updates</h3>
                                    <p>Natus error sit voluptatem accusantium laudantium.</p>
                                </div>
                                <div class="single-item">
                                    <div class="icon-box"><img src="assets/images/icons/icon-26.png" alt=""></div>
                                    <h3>Notification feature</h3>
                                    <p>Rem aperiam eaque ipsa quae ab illo inventore veritatis.</p>
                                </div>
                            </div>
                            <div class="btn-box">
                                <a href="index.php" class="theme-btn btn-three"><span>Official App</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        
        
        <section class="testimonial-section">
            <div class="auto-container">
                <div class="sec-title centred">
                    <span class="sub-title">Testimonials</span>
                    <h2>Traders <span>Words</span> About Us</h2>
                </div>
                <div class="inner-container">
                    <div class="testimonial-block">
                        <figure class="image-box"><img src="assets/images/resource/testimonial-1.png" alt=""></figure>
                        <div class="content-box">
                            <h3><img src="assets/images/icons/icon-44.png" alt="">Awesome!...</h3>
                            <p>As a seasoned trader, I've had my fair share of experiences with different brokerage firms, and Aston Options stands out as one of the best</p>
                            <ul class="rating clearfix">
                                <li><i class="flaticon-star"></i></li>
                                <li><i class="flaticon-star"></i></li>
                                <li><i class="flaticon-star"></i></li>
                                <li><i class="flaticon-star"></i></li>
                                <li><i class="flaticon-star"></i></li>
                                <li><span>(5 out of 5)</span></li>
                            </ul>
                            <span class="date">Dec 14, 2022</span>
                        </div>
                        <div class="author-box">
                            <figure class="author-thumb"><img src="assets/images/resource/testimonial-2.png" alt=""></figure>
                            <h4>Nathan Felix</h4>
                            <span class="designation">California</span>
                        </div>
                    </div>
                    <div class="testimonial-block">
                        <figure class="image-box"><img src="assets/images/resource/testimonial-4.png" alt=""></figure>
                        <div class="content-box">
                            <h3><img src="assets/images/icons/icon-44.png" alt="">It’s been fantastic!...</h3>
                            <p>I've been trading with Aston Options for over a year now, and I couldn't be happier with the experience</p>
                            <ul class="rating clearfix">
                                <li><i class="flaticon-star"></i></li>
                                <li><i class="flaticon-star"></i></li>
                                <li><i class="flaticon-star"></i></li>
                                <li><i class="flaticon-star"></i></li>
                                <li><i class="flaticon-star"></i></li>
                                <li><span>(4.5 out of 5)</span></li>
                            </ul>
                            <span class="date">Dec 14, 2022</span>
                        </div>
                        <div class="author-box">
                            <figure class="author-thumb"><img src="assets/images/resource/testimonial-3.png" alt=""></figure>
                            <h4>Nora Penelope</h4>
                            <span class="designation">San Fransisco</span>
                        </div>
                    </div>
                </div>
                <!--<div class="link-box centred">-->
                <!--    <a href="index-3.html"><span>More Reviews</span></a>-->
                <!--</div>-->
            </div>
        </section>
        <!-- apps-section end -->
        <section class="awards-section">
            <div class="auto-container">
                <div class="title-inner">
                    <div class="sec-title mr-0">
                        <span class="sub-title">Awards & Achivements</span>
                        <h2>We're Proud of Our <span>Awards</span></h2>
                    </div>
                    <!-- <div class="text-box">
                        <p>Place at facere possimus omnis volupta assum <br />enda est omnis dolor repellendus.</p>
                    </div> -->
                </div>
                <div class="three-item-carousel owl-carousel owl-theme">
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-46.png" alt=""></div>
                            <h3>Global Forex <br />Broker of the Year</h3>
                            <p>Global Forex Awards <br />Mar, 2021</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-46.png" alt=""></div>
                            <h3>Most Transparent <br />FX Broker</h3>
                            <p>The Forex Expo USA <br />Dec, 2018</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-46.png" alt=""></div>
                            <h3>Best Forex Rewards <br />Program</h3>
                            <p>Global Forex Awards <br />Jun, 2016</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-46.png" alt=""></div>
                            <h3>Global Forex <br />Broker of the Year</h3>
                            <p>Global Forex Awards <br />Mar, 2021</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-46.png" alt=""></div>
                            <h3>Most Transparent <br />FX Broker</h3>
                            <p>The Forex Expo USA <br />Dec, 2018</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-46.png" alt=""></div>
                            <h3>Best Forex Rewards <br />Program</h3>
                            <p>Global Forex Awards <br />Jun, 2016</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-46.png" alt=""></div>
                            <h3>Global Forex <br />Broker of the Year</h3>
                            <p>Global Forex Awards <br />Mar, 2021</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-46.png" alt=""></div>
                            <h3>Most Transparent <br />FX Broker</h3>
                            <p>The Forex Expo USA <br />Dec, 2018</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-46.png" alt=""></div>
                            <h3>Best Forex Rewards <br />Program</h3>
                            <p>Global Forex Awards <br />Jun, 2016</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- faq-section -->
        <!-- <section class="faq-section sec-pad">
            <div class="auto-container">
                <div class="sec-title centred">
                    <span class="sub-title">Faq’s</span>
                    <h2>Find <span>Answers</span> to Common <br />Questions</h2>
                </div>
                <div class="inner-box">
                    <ul class="accordion-box">
                        <li class="accordion block active-block">
                            <div class="acc-btn active">
                                <div class="icon-box"><i class="flaticon-plus"></i></div>
                                <span>01</span>
                                <h4>How can I start trading Forex?</h4>
                                <p>Molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas...</p>
                            </div>
                            <div class="acc-content current">
                                <div class="text">
                                    <p>Molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas Temporibus autem quibusdam et aut officiis debitis.</p>
                                </div>
                            </div>
                        </li>
                        <li class="accordion block">
                            <div class="acc-btn">
                                <div class="icon-box"><i class="flaticon-plus"></i></div>
                                <span>02</span>
                                <h4>How much money do I need to start?</h4>
                                <p>Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur...</p>
                            </div>
                            <div class="acc-content">
                                <div class="text">
                                    <p>Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur commodo Nunc tempor amet massa diam mauris Risus sodales interdum.</p>
                                </div>
                            </div>
                        </li>
                        <li class="accordion block">
                            <div class="acc-btn">
                                <div class="icon-box"><i class="flaticon-plus"></i></div>
                                <span>03</span>
                                <h4>What is margin?</h4>
                                <p>Laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem...</p>
                            </div>
                            <div class="acc-content">
                                <div class="text">
                                    <p>Laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem mattis commodo Nunc tempor amet massa diam mauris Risus sodales interdum.</p>
                                </div>
                            </div>
                        </li>
                        <li class="accordion block">
                            <div class="acc-btn">
                                <div class="icon-box"><i class="flaticon-plus"></i></div>
                                <span>04</span>
                                <h4>Can I lose more than I invest in Forex?</h4>
                                <p>Optio cumque nihil impedit quo minus id quod maxime placeat facere...</p>
                            </div>
                            <div class="acc-content">
                                <div class="text">
                                    <p>Optio cumque nihil impedit quo minus id quod maxime placeat facere commodo Nunc tempor amet massa diam mauris Risus sodales interdum.</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="link-box centred">
                    <a href="faq.php"><span>Read More</span></a>
                </div>
            </div>
        </section> -->
        <!-- faq-section end -->


        <!-- main-footer -->
     <footer class="footer-style-two">
            <div class="widget-section">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget logo-widget">
                                <figure class="footer-logo"><a href="index.php"><img src="assets/images/footer.png" alt=""></a></figure>
                                <div class="widget-content">
                                     <div class="link-box mb-10">
                                             <h5><a href="mailto:info@astonoptions.com" class="text-white"><i class="flaticon-message"></i>info@astonoptions.com</a></h5>
                            <h5><a href="mailto:support@astonoptions.com"  class="text-white"><i class="flaticon-message"></i>support@astonoptions.com</a></h5>
                                        </div><br/>
                                    <div class="year-box">
                                         
                                        <h4>Since</h4>
                                        <h2>2012</h2>
                        <!--                <div class="guide-box">-->
                          
                        <!--</div>-->
                                      
                                    </div>
                                    <div class="text-box">
                                        <p>We believe that everyone deserves the opportunity to build wealth.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_60">
                                <div class="widget-title">
                                    <h3>Company</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="about.php">About Us</a></li>
                                        <!-- <li><a href="help-center.php">Help Center</a></li> -->
                                        <li><a href="faq.php">Faq</a></li>
                                        <li><a href="contact.php">Contact Us</a></li>
                                        <!--<li><a href="blog.php">Blog</a></li>-->
                                       
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_15">
                                <div class="widget-title">
                                    <h3>Markets</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="options.php">Options Trading</a></li>
                                        <li><a href="stocks.php">Stocks Trading</a></li>
                                        <li><a href="forex.php">Forex Trading</a></li>
                                        <li><a href="fixedincome.php">Fixed Income</a></li>
                                        <li><a href="infrastructure.php">Infrastruture</a></li>
                                        <li><a href="multiasset.php">Multi Asset</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_80">
                                <div class="widget-title">
                                    <h3>Planning Service</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                    <li><a href="estate.php">Estate Planning</a></li>
                                    <li><a href="retirement.php">Retirement Planning</a></li>
                                    <li><a href="financial.php">Financial Planning</a></li>
                                    <li><a href="privatewealth.php">Private Wealth</a></li>
                                     
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom-two">
                <div class="auto-container">
                    <div class="bottom-inner"> 
                        
                        <div class="copyright-box">
                            <p>&copy; <span>2023 <a href="index.php">Aston Options</a>.</span> All Rights Reserved.</p>
                            <ul class="footer-nav clearfix">
                                <!-- <li><a href="legal.php">Legal Notice</a></li> -->
                                <li><a href="privacy.php">Privacy Policy</a></li>
                                <li><a href="terms.php">Terms & Conditions</a></li>
                            </ul>
                        </div>
                        <ul class="social-links clearfix">
                            <!-- <li><a href="index-3.html"><i class="fa-brands fa-facebook"></i></a></li>
                            <li><a href="index-3.html"><i class="fa-brands fa-instagram"></i></a></li>
                            <li><a href="index-3.html"><i class="fa-brands fa-square-pinterest"></i></a></li>
                            <li class="scroll-to-target" data-target="html"><i class="flaticon-up-arrow"></i></li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </footer>

         <!-- scroll to top -->
         <button class="scroll-top scroll-to-target" data-target="php">
            <i class="flaticon-up-arrow"></i>
        </button>
        
    </div>


    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>

</body><!-- End of .page_wrapper -->

<!-- Mirrored from azim.hostlin.com/Aston Options/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 11 Nov 2023 11:46:31 GMT -->
</php>
        <!-- main-footer end -->
        


       