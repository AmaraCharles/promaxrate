<!DOCTYPE php>
<php lang="en">

<head>
    
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="description" content="Aston Options - Your Trusted Broker for Financial Success">
    <meta name="keywords" content="Aston Options, brokers, financial, investments, trading">
    <meta name="author" content="Aston Options">

    <!-- Open Graph / Facebook -->
    

    <!-- Favicon -->
<link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon">

  <link rel="apple-touch-icon" href="https://astonoptions.com/assets/images/copy.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Aston Optionsl">
    <!-- Google / Search Engine Tags -->
    <meta itemprop="name" content="Aston Options">
    <meta itemprop="description" content="Your Trusted Broker for Financial Success">
    <meta itemprop="image" content="https://astonoptions.com/assets/images/copy.png">
    <!-- Facebook Meta Tags -->
    <meta property="og:title" content="Aston Options" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://astonoptions.com" />
    <meta property="og:image" content="https://astonoptions.com/assets/images/copy.png" />
    <meta property="og:description" content="Your Trusted Broker for Financial Success" />
    <meta property="og:site_name" content="Aston Optionsl" />

    <title>Aston Options - Your Trusted Broker</title>




<!-- Fav Icon -->

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="assets/css/font-awesome-all.css" rel="stylesheet">
<link href="assets/css/flaticon.css" rel="stylesheet">
<link href="assets/css/owl.css" rel="stylesheet">
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="assets/css/animate.css" rel="stylesheet">
<link href="assets/css/nice-select.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/responsive.css" rel="stylesheet">

</head>
<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '59ba79d2fc419942ea29a8fbc1af2f46d3be4b3a';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>

<!-- page wrapper -->
<body>

    <div class="boxed_wrapper">
 <!-- preloader -->
  <div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                        
                           
                        </div>
                    </div>  
                </div>
            </div>
        </div>
        <!-- preloader end -->


     


        <!-- main header -->
        <header class="main-header">
            <!-- header-top -->
            <div class="header-top">
                <div class="outer-container">
                   
                  <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">

  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "proName": "FOREXCOM:SPXUSD",
      "title": "S&P 500"
    },
    {
      "proName": "FOREXCOM:NSXUSD",
      "title": "US 100"
    },
    {
      "proName": "FX_IDC:EURUSD",
      "title": "EUR to USD"
    },
    {
      "proName": "BITSTAMP:BTCUSD",
      "title": "Bitcoin"
    },
    {
      "proName": "BITSTAMP:ETHUSD",
      "title": "Ethereum"
    }
  ],
  "showSymbolLogo": true,
  "colorTheme": "dark",
  "isTransparent": false,
  "displayMode": "adaptive",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="index.php"><img src="assets/images/logo.png" alt="Aston" style="width:158px;height:42px"></a></figure>
                            </div>
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                                                                         <div class="btn-box "><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one text-small  d-lg-none d-md-none"><span>Register</span></a></div>

                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li ><a href="index.php">Home</a></li>  
                                        <li ><a href="market.php">Markets</a></li>
                                        <li class="dropdown"><a href="#">Mirror Trades</a>
                                            <ul>
                                                
                                                <li><a href="forex.php">Forex</a></li>
                                                <li><a href="copy.php">Copy Trading</a></li>
                                                <li><a href="options.php">Option Trading</a></li>
                                                <li><a href="stocks.php">Stocks Trading</a></li>
                                           
                                            </ul>
                                        </li> 
                                        <li class="dropdown"><a href="#">Planning Services</a>
                                            <ul>
                                            <li><a href="estate.php">Estate Planning</a></li>
                                            <li><a href="retirement.php">Retirement Planning</a></li>
                                            <li><a href="financial.php">Financial Planning</a></li>
                                            <li><a href="privatewealth.php">Private Wealth</a></li>
                                            </ul>
                                        </li> 
                                        <li ><a href="about.php">About Us</a></li>  
                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!-- <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div> -->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a href="https://app.astonoptions.com/user/login" >Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            <div class="btn-box"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one "><span>Register</span></a></div>
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="index.php"><img src="assets/images/logo.png" alt="" style="width:158px;height:42px"></a></figure>
                            </div>
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!-- <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div> -->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a  href="https://app.astonoptions.com/user/login">Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            <div class="btn-box"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Open an A/c</span></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>
            
            <nav class="menu-box">
                <div class="nav-logo"><a href="index.php"><img src="assets/images/logo.png" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                                                <li><a href="mailto:info@astonoptions.com">info@astonoptions.com</a></li>

                        <!-- <li>Chicago 12, Melborne City, USA</li>
                        <li><a href="tel:+8801682648101">+88 01682648101</a></li> -->
                        <li><a href="mailto:support@astonoptions.com">support@astonoptions.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    

                </div>
            </nav>
        </div><!-- End Mobile Menu -->        <!-- page-title -->
        <section class="page-title centred">
            <div class="bg-layer" style="background-image: url(assets/images/background/page-title.jpg);"></div>
            <div class="line-box">
                <div class="line-1"></div>
                <div class="line-2"></div>
            </div>
            <div class="auto-container">
                <div class="content-box">
                    <h1>Contact</h1>
                    <p>Thank you for your interest in Aston Options! We value your feedback, inquiries, and any opportunities to assist you. Please feel free to reach out to us using the contact details below:</p>
                    <ul class="bread-crumb clearfix">
                        <li><a href="index.php">Home</a></li>
                        <li>About</li>
                        <li>Contact</li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- page-title end -->


        <!-- contact-style-two -->
        <section class="contact-style-two sec-pad">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-49.png);"></div>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-8 col-md-12 col-sm-12 content-column">
                        <div class="content-box">
                            <div class="sec-title">
                                <span class="sub-title">Need Help</span>
                                <!-- <h2><span>Connecting</span> World for <br />Better Solving</h2> -->
                                <p>Thank you for your interest in Aston Options! We value your feedback, inquiries, and any opportunities to assist you. Please feel free to reach out to us using the contact details below:</p>
                            </div>
                            <div class="row clearfix">
                                <div class="col-lg-6 col-md-6 col-sm-12 info-block">
                                    <div class="info-block-one">
                                        <div class="inner-box">
                                            <div class="icon-box"><img src="assets/images/icons/icon-84.png" alt=""></div>
                                            <h4>Raise Support Ticket</h4>
                                            <p>We attend to every user query as soon as we can</p>
                                            <div class="link-box">
                                                <a href="https://app.astonoptions.com/user/register"><span>Sign Up</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 info-block">
                                    <div class="info-block-one">
                                        <div class="inner-box">
                                            <div class="icon-box"><img src="assets/images/icons/icon-85.png" alt=""></div>
                                            <h4>Live Chat Support</h4>
                                            <p>Chat live with our forex specialist.</p>
                                            <div class="link-box">
                                                <button><span>Start Chat</span></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12 inner-column">
                        <div class="inner-content">
                            <h3>Contact Info</h3>
                            <ul class="info-list clearfix">
                                <li>
                                    <div class="icon-box"><img src="assets/images/icons/icon-86.png" alt=""></div>
                                    <p>191 Integer Rd, 2nd Street, LA 08219 USA.</p>
                                </li>
                                <!-- <li>
                                    <div class="icon-box"><img src="assets/images/icons/icon-87.png" alt=""></div>
                                    <p><a href="tel:122256789091">+1 222 56 78 90 & 91</a></p>
                                </li> -->
                                <li>
                                    <div class="icon-box"><img src="assets/images/icons/icon-88.png" alt=""></div>
                                    <p><a href="mailto:info@astonoptions.com">info@astonoptions.com</a></p>
                                </li>

                                <li>
                                    <div class="icon-box"><img src="assets/images/icons/icon-88.png" alt=""></div>
                                    <p><a href="mailto:support@astonoptions.com">support@astonoptions.com</a></p>
                                </li>
                            </ul>
                            <!-- <ul class="social-links clearfix">
                                <li><a href="contact.html"><i class="fa-brands fa-facebook"></i></a></li>
                                <li><a href="contact.html"><i class="fa-brands fa-square-twitter"></i></a></li>
                                <li><a href="contact.html"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="contact.html"><i class="fa-brands fa-square-pinterest"></i></a></li>
                            </ul> -->
                            <!-- <div class="btn-box">
                                <a href="https://www.google.com/maps" target="_blank" class="theme-btn btn-two"><span>View On Google Map</span></a>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- contact-style-two end -->


        <!-- contact-section -->
        <section class="contact-section alternat-2 sec-pad centred">
            <div class="auto-container">
                <div class="sec-title">
                    <span class="sub-title">Drop a Line</span>
                    <h2>Send Your <span>Message</span> to us</h2>
                </div>
                <form method="post" action="mail.php" id="contact-form"> 
                    <div class="row clearfix">
                        <div class="col-lg-6 col-md-6 col-sm-12 left-column">
                            <div class="left-content">
                                <div class="form-group">
                                    <input type="text" name="username" placeholder="Your Name" required>
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" placeholder="Email Address" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="phone" placeholder="Phone" required>
                                  
                                </div>
                                <div class="form-group">
                                    <input type="text" name="subject" placeholder="Subject" required>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 right-column">
                            <div class="right-content">
                                <div class="form-group">
                                    <textarea name="message" placeholder="Write Your Message Here..."></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="check-box">
                        <input class="check" type="checkbox" id="checkbox1">
                        <label for="checkbox1">Agree to our private policies & Conditions.</label>
                    </div>
                    <div class="message-btn">
                        <button type="submit" class="theme-btn btn-three" name="submit-form"><span>Send Now</span></button>
                    </div>
                </form>
            </div>
        </section>
        <!-- contact-section end -->


       <footer class="footer-style-two">
            <div class="widget-section">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget logo-widget">
                                <figure class="footer-logo"><a href="index.php"><img src="assets/images/footer.png" alt=""></a></figure>
                                <div class="widget-content">
                                     <div class="link-box mb-10">
                                             <h5><a href="mailto:info@astonoptions.com" class="text-white"><i class="flaticon-message"></i>info@astonoptions.com</a></h5>
                            <h5><a href="mailto:support@astonoptions.com"  class="text-white"><i class="flaticon-message"></i>support@astonoptions.com</a></h5>
                                        </div><br/>
                                    <div class="year-box">
                                         
                                        <h4>Since</h4>
                                        <h2>2012</h2>
                        <!--                <div class="guide-box">-->
                          
                        <!--</div>-->
                                      
                                    </div>
                                    <div class="text-box">
                                        <p>We believe that everyone deserves the opportunity to build wealth.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_60">
                                <div class="widget-title">
                                    <h3>Company</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="about.php">About Us</a></li>
                                        <!-- <li><a href="help-center.php">Help Center</a></li> -->
                                        <li><a href="faq.php">Faq</a></li>
                                        <li><a href="contact.php">Contact Us</a></li>
                                        <!--<li><a href="blog.php">Blog</a></li>-->
                                       
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_15">
                                <div class="widget-title">
                                    <h3>Markets</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="options.php">Options Trading</a></li>
                                        <li><a href="stocks.php">Stocks Trading</a></li>
                                        <li><a href="forex.php">Forex Trading</a></li>
                                        <li><a href="fixedincome.php">Fixed Income</a></li>
                                        <li><a href="infrastructure.php">Infrastruture</a></li>
                                        <li><a href="multiasset.php">Multi Asset</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_80">
                                <div class="widget-title">
                                    <h3>Planning Service</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                    <li><a href="estate.php">Estate Planning</a></li>
                                    <li><a href="retirement.php">Retirement Planning</a></li>
                                    <li><a href="financial.php">Financial Planning</a></li>
                                    <li><a href="privatewealth.php">Private Wealth</a></li>
                                     
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom-two">
                <div class="auto-container">
                    <div class="bottom-inner"> 
                        
                        <div class="copyright-box">
                            <p>&copy; <span>2023 <a href="index.php">Aston Options</a>.</span> All Rights Reserved.</p>
                            <ul class="footer-nav clearfix">
                                <!-- <li><a href="legal.php">Legal Notice</a></li> -->
                                <li><a href="privacy.php">Privacy Policy</a></li>
                                <li><a href="terms.php">Terms & Conditions</a></li>
                            </ul>
                        </div>
                        <ul class="social-links clearfix">
                            <!-- <li><a href="index-3.html"><i class="fa-brands fa-facebook"></i></a></li>
                            <li><a href="index-3.html"><i class="fa-brands fa-instagram"></i></a></li>
                            <li><a href="index-3.html"><i class="fa-brands fa-square-pinterest"></i></a></li>
                            <li class="scroll-to-target" data-target="html"><i class="flaticon-up-arrow"></i></li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </footer>

         <!-- scroll to top -->
         <button class="scroll-top scroll-to-target" data-target="php">
            <i class="flaticon-up-arrow"></i>
        </button>
        
    </div>


    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>

</body><!-- End of .page_wrapper -->

<!-- Mirrored from azim.hostlin.com/Aston Options/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 11 Nov 2023 11:46:31 GMT -->
</php>
