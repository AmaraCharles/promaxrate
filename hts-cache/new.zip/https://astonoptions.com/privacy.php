<!DOCTYPE php>
<php lang="en">

<head>
    
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="description" content="Aston Options - Your Trusted Broker for Financial Success">
    <meta name="keywords" content="Aston Options, brokers, financial, investments, trading">
    <meta name="author" content="Aston Options">

    <!-- Open Graph / Facebook -->
    

    <!-- Favicon -->
<link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon">

  <link rel="apple-touch-icon" href="https://astonoptions.com/assets/images/copy.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Aston Optionsl">
    <!-- Google / Search Engine Tags -->
    <meta itemprop="name" content="Aston Options">
    <meta itemprop="description" content="Your Trusted Broker for Financial Success">
    <meta itemprop="image" content="https://astonoptions.com/assets/images/copy.png">
    <!-- Facebook Meta Tags -->
    <meta property="og:title" content="Aston Options" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://astonoptions.com" />
    <meta property="og:image" content="https://astonoptions.com/assets/images/copy.png" />
    <meta property="og:description" content="Your Trusted Broker for Financial Success" />
    <meta property="og:site_name" content="Aston Optionsl" />

    <title>Aston Options - Your Trusted Broker</title>




<!-- Fav Icon -->

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="assets/css/font-awesome-all.css" rel="stylesheet">
<link href="assets/css/flaticon.css" rel="stylesheet">
<link href="assets/css/owl.css" rel="stylesheet">
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="assets/css/animate.css" rel="stylesheet">
<link href="assets/css/nice-select.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/responsive.css" rel="stylesheet">

</head>
<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '59ba79d2fc419942ea29a8fbc1af2f46d3be4b3a';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>

<!-- page wrapper -->
<body>

    <div class="boxed_wrapper">
 <!-- preloader -->
  <div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                        
                           
                        </div>
                    </div>  
                </div>
            </div>
        </div>
        <!-- preloader end -->


     


        <!-- main header -->
        <header class="main-header">
            <!-- header-top -->
            <div class="header-top">
                <div class="outer-container">
                   
                  <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">

  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "proName": "FOREXCOM:SPXUSD",
      "title": "S&P 500"
    },
    {
      "proName": "FOREXCOM:NSXUSD",
      "title": "US 100"
    },
    {
      "proName": "FX_IDC:EURUSD",
      "title": "EUR to USD"
    },
    {
      "proName": "BITSTAMP:BTCUSD",
      "title": "Bitcoin"
    },
    {
      "proName": "BITSTAMP:ETHUSD",
      "title": "Ethereum"
    }
  ],
  "showSymbolLogo": true,
  "colorTheme": "dark",
  "isTransparent": false,
  "displayMode": "adaptive",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="index.php"><img src="assets/images/logo.png" alt="Aston" style="width:158px;height:42px"></a></figure>
                            </div>
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                                                                         <div class="btn-box "><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one text-small  d-lg-none d-md-none"><span>Register</span></a></div>

                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li ><a href="index.php">Home</a></li>  
                                        <li ><a href="market.php">Markets</a></li>
                                        <li class="dropdown"><a href="#">Mirror Trades</a>
                                            <ul>
                                                
                                                <li><a href="forex.php">Forex</a></li>
                                                <li><a href="copy.php">Copy Trading</a></li>
                                                <li><a href="options.php">Option Trading</a></li>
                                                <li><a href="stocks.php">Stocks Trading</a></li>
                                           
                                            </ul>
                                        </li> 
                                        <li class="dropdown"><a href="#">Planning Services</a>
                                            <ul>
                                            <li><a href="estate.php">Estate Planning</a></li>
                                            <li><a href="retirement.php">Retirement Planning</a></li>
                                            <li><a href="financial.php">Financial Planning</a></li>
                                            <li><a href="privatewealth.php">Private Wealth</a></li>
                                            </ul>
                                        </li> 
                                        <li ><a href="about.php">About Us</a></li>  
                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!-- <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div> -->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a href="https://app.astonoptions.com/user/login" >Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            <div class="btn-box"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one "><span>Register</span></a></div>
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="index.php"><img src="assets/images/logo.png" alt="" style="width:158px;height:42px"></a></figure>
                            </div>
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!-- <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div> -->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a  href="https://app.astonoptions.com/user/login">Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            <div class="btn-box"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Open an A/c</span></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>
            
            <nav class="menu-box">
                <div class="nav-logo"><a href="index.php"><img src="assets/images/logo.png" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                                                <li><a href="mailto:info@astonoptions.com">info@astonoptions.com</a></li>

                        <!-- <li>Chicago 12, Melborne City, USA</li>
                        <li><a href="tel:+8801682648101">+88 01682648101</a></li> -->
                        <li><a href="mailto:support@astonoptions.com">support@astonoptions.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    

                </div>
            </nav>
        </div><!-- End Mobile Menu -->
<!-- page-title -->
<section class="page-title centred">
    <div class="bg-layer" style="background-image: url(assets/images/background/page-title.jpg);"></div>
    <div class="line-box">
        <div class="line-1"></div>
        <div class="line-2"></div>
    </div>
    <div class="auto-container">
        <div class="content-box">
            <h1>Aston Options Privacy Policy</h1>
            <!-- <p>Deaching of the great explorer of the truth the builder</p> -->
            <ul class="bread-crumb clearfix">
                <li><a href="index.php">Home</a></li>
                
                <li>Aston Options Privacy Policy </li>

            </ul>
        </div>
    </div>
</section>
<!-- page-title end -->


<!-- sidebar-page-container -->
<section class="sidebar-page-container blog-details">
    <div class="auto-container">
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 content-side">
                <div class="blog-details-content">
                    <div class="news-block-one">
                        <div class="inner-box">
                            <div class="lower-content">

                                <h2>Aston Options Privacy Policy</h2>
                                <!-- <p>Mastering Stock Trading: Your Comprehensive Guide on Aston Options</p> -->
                            </div>
                            <div class="image-box">
                                <figure class="image"><img src="assets/images/legal.jpg" style="height:300px" alt=""></figure>

                            </div>
                        </div>
                    </div>
                    <div class="content-one">
                        <p>Welcome to Aston Options! Protecting your privacy is important to us. This Privacy Policy outlines how Aston Options ("we," "our," or "us") collects, uses, shares, and protects your personal information when you use our website, mobile application, or any related services (collectively referred to as the "Services").</p>
     
                    </div>
                   





                    <div class="content-two">
                    <h3>  Information We Collect: </h3>
                        <p> <h4>   a. Personal Information: </h4>We may collect personal information such as your name, email address, contact information, and other details you provide when using our Services.</p>


                        <p> <h4>  b. Usage Data:</h4> We automatically collect information about your use of our Services, including your IP address, device information, and browsing behavior.</p>
                        <h3>  How We Use Your Information: </h3>
                        <p>a. We use the information we collect to provide, maintain, and improve our Services. </p>
                        <p>b. Personal information may be used to communicate with you, respond to inquiries, and send important updates.
 </p>
                        <p>c. We may use cookies and similar technologies to enhance your experience and gather information about how you interact with our Services.
 </p>
                       
                    </div>

                 


                   
                   
























                    <div class="content-three">
                        
                       <p><h4>Information Sharing:</h4>
                       <p>a. We do not sell, rent, or trade your personal information to third parties.
</p>
                       <p>b. We may share your information with trusted third-party service providers who assist us in delivering and improving our Services.
</p>
                       <p>c. Your information may be disclosed to comply with legal obligations or protect our rights, property, or safety.
</p>
                    
                    
                    </p>
                    <p><h4>Security:</h4>
                    <p>a. We implement security measures to protect your personal information from unauthorized access, disclosure, alteration, and destruction.
</p>
                    <p>b. Despite our efforts, no data transmission over the internet or electronic storage is completely secure. We cannot guarantee the absolute security of your information.
</p>

</p>
<p><h4>Your Choices:</h4>
<p>a. You can control cookies preferences through your browser settings.
</p>
<p>b. You may opt-out of receiving promotional communications from us by following the instructions in our emails.
</p>
<p>c. You can request access, correction, or deletion of your personal information by contacting us at <a href="mailto:support@astonoptions.com">Legal Team</a>.
</p>
</p>








<p><h4>Children's Privacy:
</h4>Aston Options does not knowingly collect personal information from children under the age of 13. If we become aware that we have collected personal information from a child under the age of 13, we will take steps to delete the information as soon as possible.
</p>
<p><h4>Changes to the Privacy Policy:
</h4>We may update our Privacy Policy from time to time. Any changes will be effective when posted on our website. We encourage you to review this Privacy Policy periodically for any updates.
</p>
<p><h4>Contact Us:</h4>If you have any questions or concerns about our Privacy Policy, please contact us at <a href="mailto:support@astonoptions.com">Legal Team</a>.
</p>
<p></p>
<p>Thank you for trusting Aston Options with your information.
</p>


                     
        

                        <!-- <h4>Everything you need to trade Forex in one place</h4>
                                <ul class="list-style-one clearfix">
                                    <li>Et harum quidem rerum facilis est expedita.</li>
                                    <li>officiis debitis aut rerum.</li>
                                    <li>Temporibus autem quibusdam et aut.</li>
                                </ul>
                                <p>Foresee the pain and trouble that are bound to ensue & equal blame belongs to those who fail in their duty through weakness of will, which is the same as shrinking.</p> -->

                       
                        <!--  <p><h4></h4></p>
                                <p><h4></h4></p> -->
                    </div>

                </div>

            </div>

        </div>
    </div>
</section>
<!-- sidebar-page-container end -->


<footer class="footer-style-two">
            <div class="widget-section">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget logo-widget">
                                <figure class="footer-logo"><a href="index.php"><img src="assets/images/footer.png" alt=""></a></figure>
                                <div class="widget-content">
                                     <div class="link-box mb-10">
                                             <h5><a href="mailto:info@astonoptions.com" class="text-white"><i class="flaticon-message"></i>info@astonoptions.com</a></h5>
                            <h5><a href="mailto:support@astonoptions.com"  class="text-white"><i class="flaticon-message"></i>support@astonoptions.com</a></h5>
                                        </div><br/>
                                    <div class="year-box">
                                         
                                        <h4>Since</h4>
                                        <h2>2012</h2>
                        <!--                <div class="guide-box">-->
                          
                        <!--</div>-->
                                      
                                    </div>
                                    <div class="text-box">
                                        <p>We believe that everyone deserves the opportunity to build wealth.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_60">
                                <div class="widget-title">
                                    <h3>Company</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="about.php">About Us</a></li>
                                        <!-- <li><a href="help-center.php">Help Center</a></li> -->
                                        <li><a href="faq.php">Faq</a></li>
                                        <li><a href="contact.php">Contact Us</a></li>
                                        <!--<li><a href="blog.php">Blog</a></li>-->
                                       
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_15">
                                <div class="widget-title">
                                    <h3>Markets</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="options.php">Options Trading</a></li>
                                        <li><a href="stocks.php">Stocks Trading</a></li>
                                        <li><a href="forex.php">Forex Trading</a></li>
                                        <li><a href="fixedincome.php">Fixed Income</a></li>
                                        <li><a href="infrastructure.php">Infrastruture</a></li>
                                        <li><a href="multiasset.php">Multi Asset</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_80">
                                <div class="widget-title">
                                    <h3>Planning Service</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                    <li><a href="estate.php">Estate Planning</a></li>
                                    <li><a href="retirement.php">Retirement Planning</a></li>
                                    <li><a href="financial.php">Financial Planning</a></li>
                                    <li><a href="privatewealth.php">Private Wealth</a></li>
                                     
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom-two">
                <div class="auto-container">
                    <div class="bottom-inner"> 
                        
                        <div class="copyright-box">
                            <p>&copy; <span>2023 <a href="index.php">Aston Options</a>.</span> All Rights Reserved.</p>
                            <ul class="footer-nav clearfix">
                                <!-- <li><a href="legal.php">Legal Notice</a></li> -->
                                <li><a href="privacy.php">Privacy Policy</a></li>
                                <li><a href="terms.php">Terms & Conditions</a></li>
                            </ul>
                        </div>
                        <ul class="social-links clearfix">
                            <!-- <li><a href="index-3.html"><i class="fa-brands fa-facebook"></i></a></li>
                            <li><a href="index-3.html"><i class="fa-brands fa-instagram"></i></a></li>
                            <li><a href="index-3.html"><i class="fa-brands fa-square-pinterest"></i></a></li>
                            <li class="scroll-to-target" data-target="html"><i class="flaticon-up-arrow"></i></li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </footer>

         <!-- scroll to top -->
         <button class="scroll-top scroll-to-target" data-target="php">
            <i class="flaticon-up-arrow"></i>
        </button>
        
    </div>


    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>

</body><!-- End of .page_wrapper -->

<!-- Mirrored from azim.hostlin.com/Aston Options/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 11 Nov 2023 11:46:31 GMT -->
</php>
