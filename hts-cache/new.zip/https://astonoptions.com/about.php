<!DOCTYPE php>
<php lang="en">

<head>
    
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="description" content="Aston Options - Your Trusted Broker for Financial Success">
    <meta name="keywords" content="Aston Options, brokers, financial, investments, trading">
    <meta name="author" content="Aston Options">

    <!-- Open Graph / Facebook -->
    

    <!-- Favicon -->
<link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon">

  <link rel="apple-touch-icon" href="https://astonoptions.com/assets/images/copy.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Aston Optionsl">
    <!-- Google / Search Engine Tags -->
    <meta itemprop="name" content="Aston Options">
    <meta itemprop="description" content="Your Trusted Broker for Financial Success">
    <meta itemprop="image" content="https://astonoptions.com/assets/images/copy.png">
    <!-- Facebook Meta Tags -->
    <meta property="og:title" content="Aston Options" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://astonoptions.com" />
    <meta property="og:image" content="https://astonoptions.com/assets/images/copy.png" />
    <meta property="og:description" content="Your Trusted Broker for Financial Success" />
    <meta property="og:site_name" content="Aston Optionsl" />

    <title>Aston Options - Your Trusted Broker</title>




<!-- Fav Icon -->

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="assets/css/font-awesome-all.css" rel="stylesheet">
<link href="assets/css/flaticon.css" rel="stylesheet">
<link href="assets/css/owl.css" rel="stylesheet">
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="assets/css/animate.css" rel="stylesheet">
<link href="assets/css/nice-select.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/responsive.css" rel="stylesheet">

</head>
<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '59ba79d2fc419942ea29a8fbc1af2f46d3be4b3a';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>

<!-- page wrapper -->
<body>

    <div class="boxed_wrapper">
 <!-- preloader -->
  <div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                        
                           
                        </div>
                    </div>  
                </div>
            </div>
        </div>
        <!-- preloader end -->


     


        <!-- main header -->
        <header class="main-header">
            <!-- header-top -->
            <div class="header-top">
                <div class="outer-container">
                   
                  <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">

  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "proName": "FOREXCOM:SPXUSD",
      "title": "S&P 500"
    },
    {
      "proName": "FOREXCOM:NSXUSD",
      "title": "US 100"
    },
    {
      "proName": "FX_IDC:EURUSD",
      "title": "EUR to USD"
    },
    {
      "proName": "BITSTAMP:BTCUSD",
      "title": "Bitcoin"
    },
    {
      "proName": "BITSTAMP:ETHUSD",
      "title": "Ethereum"
    }
  ],
  "showSymbolLogo": true,
  "colorTheme": "dark",
  "isTransparent": false,
  "displayMode": "adaptive",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="index.php"><img src="assets/images/logo.png" alt="Aston" style="width:158px;height:42px"></a></figure>
                            </div>
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                                                                         <div class="btn-box "><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one text-small  d-lg-none d-md-none"><span>Register</span></a></div>

                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li ><a href="index.php">Home</a></li>  
                                        <li ><a href="market.php">Markets</a></li>
                                        <li class="dropdown"><a href="#">Mirror Trades</a>
                                            <ul>
                                                
                                                <li><a href="forex.php">Forex</a></li>
                                                <li><a href="copy.php">Copy Trading</a></li>
                                                <li><a href="options.php">Option Trading</a></li>
                                                <li><a href="stocks.php">Stocks Trading</a></li>
                                           
                                            </ul>
                                        </li> 
                                        <li class="dropdown"><a href="#">Planning Services</a>
                                            <ul>
                                            <li><a href="estate.php">Estate Planning</a></li>
                                            <li><a href="retirement.php">Retirement Planning</a></li>
                                            <li><a href="financial.php">Financial Planning</a></li>
                                            <li><a href="privatewealth.php">Private Wealth</a></li>
                                            </ul>
                                        </li> 
                                        <li ><a href="about.php">About Us</a></li>  
                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!-- <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div> -->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a href="https://app.astonoptions.com/user/login" >Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            <div class="btn-box"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one "><span>Register</span></a></div>
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="index.php"><img src="assets/images/logo.png" alt="" style="width:158px;height:42px"></a></figure>
                            </div>
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!-- <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div> -->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a  href="https://app.astonoptions.com/user/login">Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            <div class="btn-box"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Open an A/c</span></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>
            
            <nav class="menu-box">
                <div class="nav-logo"><a href="index.php"><img src="assets/images/logo.png" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                                                <li><a href="mailto:info@astonoptions.com">info@astonoptions.com</a></li>

                        <!-- <li>Chicago 12, Melborne City, USA</li>
                        <li><a href="tel:+8801682648101">+88 01682648101</a></li> -->
                        <li><a href="mailto:support@astonoptions.com">support@astonoptions.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    

                </div>
            </nav>
        </div><!-- End Mobile Menu -->
        <!-- page-title -->
        <section class="page-title centred">
            <div class="bg-layer" style="background-image: url(assets/images/background/page-title.jpg);"></div>
            <div class="line-box">
                <div class="line-1"></div>
                <div class="line-2"></div>
            </div>
            <div class="auto-container">
                <div class="content-box">
                    <h1>Aston Options</h1>
                    <p>Welcome to Aston Options, where financial empowerment meets seamless investment experiences. </p>
                    <ul class="bread-crumb clearfix">
                        <li><a href="index.php">Home</a></li>
                        <li>About</li>
                        
                    </ul>
                </div>
            </div>
        </section>
        <!-- page-title end -->


        <!-- about-style-two -->
        <section class="about-style-two">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <figure class="image-box"><img src="assets/images/resource/about-2.jpg" alt=""></figure>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content-box">
                            <div class="sec-title">
                                <span class="sub-title">About Aston Options</span>
                                <h2>Proud to be the <br />World's Leading <span>Forex Trading</span> Platform</h2>
                            </div>
                            <p> We understand that your financial journey is unique, and that's why we've crafted a platform that goes beyond traditional brokerage services. At Aston Options, we are dedicated to empowering individuals with the tools, knowledge, and personalized support they need to navigate the dynamic world of finance successfully.</p>
                            <div class="inner-box">
                                <h4>Since</h4>
                                <h2>2012</h2>
                                <div class="link-box"><a  href="https://app.astonoptions.com/user/register"><span>Get Started</span></a></div>
                            </div>
                            <p>Whether you're saving for a home, planning for retirement, or looking to grow your wealth, Aston Options provides the tools</p>
                            <div class="btn-box">
                                <a  href="https://app.astonoptions.com/user/login" class="theme-btn btn-three"><span>Login</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about-style-two end -->


        <!-- statements-section -->
        <section class="statements-section">
            <div class="auto-container">
                <div class="tabs-box">
                    <div class="tab-btn-box">
                        <ul class="tab-btns tab-buttons clearfix">
                            <li class="tab-btn active-btn" data-tab="#tab-1">
                                <span>Mission</span>
                                <div class="icon-box"><img src="assets/images/icons/icon-71.png" alt=""></div>
                            </li>
                            <li class="tab-btn" data-tab="#tab-2">
                                <span>Vision</span>
                                <div class="icon-box"><img src="assets/images/icons/icon-72.png" alt=""></div>
                            </li>
                            <!-- <li class="tab-btn" data-tab="#tab-3">
                                <span>Value</span>
                                <div class="icon-box"><img src="assets/images/icons/icon-73.png" alt=""></div>
                            </li> -->
                        </ul>
                    </div>
                    <div class="tabs-content">
                        <div class="tab active-tab" id="tab-1">
                            <div class="inner-box">
                                <div class="content-box">
                                    <div class="sec-title">
                                        <span class="sub-title">Statements</span>
                                        <h2>Our Mission</h2>
                                    </div>
                                    <p>Empowering individuals to achieve financial success by providing a comprehensive and accessible platform, coupled with expert guidance and educational resources.</p>
                                    <ul class="list-style-one clearfix">
                                        <li>Integrity</li>
                                        <!-- <li>officiis debitis aut rerum.</li>
                                        <li>Temporibus autem quibusdam et aut.</li> -->
                                    </ul>
                                    <div class="link-box">
                                        <div class="icon-box"><img src="assets/images/icons/icon-74.png" alt=""></div>
                                        <!-- <button type="button"><span>Our Statements</span></button> -->
                                    </div>
                                </div>
                                <figure class="image-box"><img src="assets/images/resource/about-3.jpg" alt=""></figure>
                            </div>
                        </div>
                        <div class="tab" id="tab-2">
                            <div class="inner-box">
                                <div class="content-box">
                                    <div class="sec-title">
                                        <span class="sub-title">Statements</span>
                                        <h2>Our Vision</h2>
                                    </div>
                                    <p>Our vision is simple yet powerful – we envision a world where everyone has the knowledge and resources to take control of their financial future. Whether you're a seasoned investor or just starting your financial journey, Aston Options is here to provide the guidance and support you need to elevate your financial potential.</p>
                                    <ul class="list-style-one clearfix">
                                        <li>Transparency</li>
                                        <li>Innovation</li>
                                        <li>Client-Centric</li>
                                    </ul>
                                    <div class="link-box">
                                        <div class="icon-box"><img src="assets/images/icons/icon-74.png" alt=""></div>
                                        <!-- <button type="button"><span>Our Statements</span></button> -->
                                    </div>
                                </div>
                                <figure class="image-box"><img src="assets/images/resource/about-3.jpg" alt=""></figure>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </section>
        <!-- statements-section end -->


        <!-- chooseus-style-two -->
        <section class="chooseus-style-two sec-pad">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-20.png);"></div>
            <figure class="image-layer"><img src="assets/images/resource/chooseus-1.png" alt=""></figure>
            <div class="auto-container">
                <div class="sec-title centred light">
                    <span class="sub-title">Why Aston Options</span>
                    <h2>We Stay Simple<span> and Proficient</span></h2>
                </div>
                <div class="inner-box">
                    <div class="left-column">
                        <div class="single-item">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-16.png);"></div>
                            <div class="icon-box">
                                <div class="icon"><img src="assets/images/icons/icon-40.png" alt=""></div>
                            </div>
                            <div class="title-text"><h3>Comprehensive Investment Platform<span></span></h3></div>
                            <p>Access real-time market data, advanced analytics, and a user-friendly interface designed to enhance your investment experience.</p>
                        </div>
                        <div class="single-item">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-17.png);"></div>
                            <div class="title-text"><h3>Tailored Financial Solutions<span></span></h3></div>
                            <p> Aston Options provides the tools and resources to align your investments with your aspirations.</p>
                            <div class="icon-box">
                                <div class="icon"><img src="assets/images/icons/icon-41.png" alt=""></div>
                            </div>
                        </div>
                    </div>
                    <div class="right-column">
                        <div class="single-item">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-18.png);"></div>
                            <div class="icon-box">
                                <div class="icon"><img src="assets/images/icons/icon-40.png" alt=""></div>
                            </div>
                            <div class="title-text"><h3>24/7 Support<span></span></h3></div>
                            <p>Our support team are always ready to assist you with any issues you are facing.</p>
                        </div>
                        <div class="single-item">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-19.png);"></div>
                            <div class="title-text"><h3>Award winner<span></span></h3></div>
                            <p>We are pioneers in the indusries an have been given lots of awards.</p>
                            <div class="icon-box">
                                <div class="icon"><img src="assets/images/icons/icon-41.png" alt=""></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- chooseus-style-two end -->


     


        <!-- funfact-section -->
        <section class="funfact-section sec-pad centred">
            <div class="auto-container">
                <div class="sec-title">
                    <span class="sub-title">Interesting Numbers</span>
                    <h2><span>Achievements</span> of our Company</h2>
                </div>
                <div class="inner-box">
                    <div class="funfact-block-one">
                        <div class="shape">
                            <div class="shape-1" style="background-image: url(assets/images/shape/shape-9.png);"></div>
                            <div class="shape-2" style="background-image: url(assets/images/shape/shape-10.png);"></div>
                            <div class="shape-3" style="background-image: url(assets/images/shape/shape-48.png);"></div>
                        </div>
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="49">0</span><span class="small-text">M</span>
                        </div>
                        <p>Active Traders</p>
                        <div class="icon-box"><img src="assets/images/icons/icon-76.png" alt=""></div>
                    </div>
                    <div class="funfact-block-one">
                        <div class="shape">
                            <div class="shape-1" style="background-image: url(assets/images/shape/shape-9.png);"></div>
                            <div class="shape-2" style="background-image: url(assets/images/shape/shape-10.png);"></div>
                            <div class="shape-3" style="background-image: url(assets/images/shape/shape-48.png);"></div>
                        </div>
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="3.7">0</span><span class="small-text">B</span>
                        </div>
                        <p>Market Capitalisation</p>
                        <div class="icon-box"><img src="assets/images/icons/icon-77.png" alt=""></div>
                    </div>
                    <div class="funfact-block-one">
                        <div class="shape">
                            <div class="shape-1" style="background-image: url(assets/images/shape/shape-9.png);"></div>
                            <div class="shape-2" style="background-image: url(assets/images/shape/shape-10.png);"></div>
                            <div class="shape-3" style="background-image: url(assets/images/shape/shape-48.png);"></div>
                        </div>
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="73.4">0</span><span class="small-text">M</span>
                        </div>
                        <p>Total Revenue</p>
                        <div class="icon-box"><img src="assets/images/icons/icon-78.png" alt=""></div>
                    </div>
                    <div class="funfact-block-one">
                        <div class="shape">
                            <div class="shape-1" style="background-image: url(assets/images/shape/shape-9.png);"></div>
                            <div class="shape-2" style="background-image: url(assets/images/shape/shape-10.png);"></div>
                            <div class="shape-3" style="background-image: url(assets/images/shape/shape-48.png);"></div>
                        </div>
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="09">0</span><span class="small-text"></span>
                        </div>
                        <p>Awards Won</p>
                        <div class="icon-box"><img src="assets/images/icons/icon-79.png" alt=""></div>
                    </div>
                    <div class="funfact-block-one">
                        <div class="shape">
                            <div class="shape-1" style="background-image: url(assets/images/shape/shape-9.png);"></div>
                            <div class="shape-2" style="background-image: url(assets/images/shape/shape-10.png);"></div>
                            <div class="shape-3" style="background-image: url(assets/images/shape/shape-48.png);"></div>
                        </div>
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="99">0</span><span>+</span>
                        </div>
                        <p>Offices & Branches</p>
                        <div class="icon-box"><img src="assets/images/icons/icon-80.png" alt=""></div>
                    </div>
                </div>
                <!-- <div class="lower-box">
                    <ul class="author-box clearfix">
                        <li><img src="assets/images/resource/author-1.png" alt=""></li>
                        <li><img src="assets/images/resource/author-2.png" alt=""></li>
                        <li><img src="assets/images/resource/author-3.png" alt=""></li>
                    </ul>
                    <h5>Average rating of 4.89/5 <br />on Trustpilot</h5>
                </div> -->
            </div>
        </section>
        <!-- funfact-section end -->


        <!-- growth-section -->
        <section class="growth-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content-box">
                            <div class="sec-title light">
                                <span class="sub-title">Growth Rate</span>
                                <h2>For Traders who <span>Value</span> Transparency</h2>
                            </div>
                            <div class="text-box">
                                <p>we are committed to elevating, educating, and empowering our users</p>
                                <!-- <a href="about.html" class="theme-btn btn-one"><span>Official App</span></a> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 inner-column">
                        <div class="growth-content">
                            <h5>Annual growth rate  2021 - 2022</h5>
                            <div class="progress-inner">
                                <div class="link-box">
                                    <span class="line line-1"></span>
                                    <span class="line line-2"></span>
                                    <span class="line line-3"></span>
                                    <span class="line line-4"></span>
                                    <span class="line line-5"></span>
                                    <span class="line line-6"></span>
                                </div>
                                <div class="bar-text">
                                    <span class="text text-1">0</span>
                                    <span class="text text-2">20</span>
                                    <span class="text text-3">40</span>
                                    <span class="text text-4">60</span>
                                    <span class="text text-5">80</span>
                                    <span class="text text-6">100</span>
                                </div>
                                <div class="progress-box">
                                    <h6>Users Satisfaction</h6>
                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="98%"></div>
                                        <div class="count-text">98%</div>
                                    </div>
                                </div>
                                <div class="progress-box">
                                    <h6>Server Down Time</h6>
                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="0%"></div>
                                        <div class="count-text">0%</div>
                                    </div>
                                </div>
                                <div class="progress-box">
                                    <h6>Partners Growth</h6>
                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="85%"></div>
                                        <div class="count-text">85%</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- growth-section end -->


    


        <!-- awards-section -->
        <section class="awards-section">
            <div class="auto-container">
                <div class="title-inner">
                    <div class="sec-title mr-0">
                        <span class="sub-title">Awards & Achivements</span>
                        <h2>We're Proud of Our <span>Awards</span></h2>
                    </div>
                    <div class="text-box">
                        <p>Place at facere possimus omnis volupta assum <br />enda est omnis dolor repellendus.</p>
                    </div>
                </div>
                <div class="three-item-carousel owl-carousel owl-theme">
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-81.png" alt=""></div>
                            <h3>Global Forex <br />Broker of the Year</h3>
                            <p>Global Forex Awards <br />Mar, 2021</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-81.png" alt=""></div>
                            <h3>Most Transparent <br />FX Broker</h3>
                            <p>The Forex Expo USA <br />Dec, 2018</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-81.png" alt=""></div>
                            <h3>Best Forex Rewards <br />Program</h3>
                            <p>Global Forex Awards <br />Jun, 2016</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-81.png" alt=""></div>
                            <h3>Global Forex <br />Broker of the Year</h3>
                            <p>Global Forex Awards <br />Mar, 2021</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-81.png" alt=""></div>
                            <h3>Most Transparent <br />FX Broker</h3>
                            <p>The Forex Expo USA <br />Dec, 2018</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-81.png" alt=""></div>
                            <h3>Best Forex Rewards <br />Program</h3>
                            <p>Global Forex Awards <br />Jun, 2016</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-81.png" alt=""></div>
                            <h3>Global Forex <br />Broker of the Year</h3>
                            <p>Global Forex Awards <br />Mar, 2021</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-81.png" alt=""></div>
                            <h3>Most Transparent <br />FX Broker</h3>
                            <p>The Forex Expo USA <br />Dec, 2018</p>
                        </div>
                    </div>
                    <div class="awards-block-one">
                        <div class="inner-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-21.png);"></div>
                            <div class="icon-box"><img src="assets/images/icons/icon-81.png" alt=""></div>
                            <h3>Best Forex Rewards <br />Program</h3>
                            <p>Global Forex Awards <br />Jun, 2016</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- awards-section end -->





        <!-- main-footer -->
       <footer class="footer-style-two">
            <div class="widget-section">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget logo-widget">
                                <figure class="footer-logo"><a href="index.php"><img src="assets/images/footer.png" alt=""></a></figure>
                                <div class="widget-content">
                                     <div class="link-box mb-10">
                                             <h5><a href="mailto:info@astonoptions.com" class="text-white"><i class="flaticon-message"></i>info@astonoptions.com</a></h5>
                            <h5><a href="mailto:support@astonoptions.com"  class="text-white"><i class="flaticon-message"></i>support@astonoptions.com</a></h5>
                                        </div><br/>
                                    <div class="year-box">
                                         
                                        <h4>Since</h4>
                                        <h2>2012</h2>
                        <!--                <div class="guide-box">-->
                          
                        <!--</div>-->
                                      
                                    </div>
                                    <div class="text-box">
                                        <p>We believe that everyone deserves the opportunity to build wealth.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_60">
                                <div class="widget-title">
                                    <h3>Company</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="about.php">About Us</a></li>
                                        <!-- <li><a href="help-center.php">Help Center</a></li> -->
                                        <li><a href="faq.php">Faq</a></li>
                                        <li><a href="contact.php">Contact Us</a></li>
                                        <!--<li><a href="blog.php">Blog</a></li>-->
                                       
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_15">
                                <div class="widget-title">
                                    <h3>Markets</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="options.php">Options Trading</a></li>
                                        <li><a href="stocks.php">Stocks Trading</a></li>
                                        <li><a href="forex.php">Forex Trading</a></li>
                                        <li><a href="fixedincome.php">Fixed Income</a></li>
                                        <li><a href="infrastructure.php">Infrastruture</a></li>
                                        <li><a href="multiasset.php">Multi Asset</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_80">
                                <div class="widget-title">
                                    <h3>Planning Service</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                    <li><a href="estate.php">Estate Planning</a></li>
                                    <li><a href="retirement.php">Retirement Planning</a></li>
                                    <li><a href="financial.php">Financial Planning</a></li>
                                    <li><a href="privatewealth.php">Private Wealth</a></li>
                                     
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom-two">
                <div class="auto-container">
                    <div class="bottom-inner"> 
                        
                        <div class="copyright-box">
                            <p>&copy; <span>2023 <a href="index.php">Aston Options</a>.</span> All Rights Reserved.</p>
                            <ul class="footer-nav clearfix">
                                <!-- <li><a href="legal.php">Legal Notice</a></li> -->
                                <li><a href="privacy.php">Privacy Policy</a></li>
                                <li><a href="terms.php">Terms & Conditions</a></li>
                            </ul>
                        </div>
                        <ul class="social-links clearfix">
                            <!-- <li><a href="index-3.html"><i class="fa-brands fa-facebook"></i></a></li>
                            <li><a href="index-3.html"><i class="fa-brands fa-instagram"></i></a></li>
                            <li><a href="index-3.html"><i class="fa-brands fa-square-pinterest"></i></a></li>
                            <li class="scroll-to-target" data-target="html"><i class="flaticon-up-arrow"></i></li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </footer>

         <!-- scroll to top -->
         <button class="scroll-top scroll-to-target" data-target="php">
            <i class="flaticon-up-arrow"></i>
        </button>
        
    </div>


    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>

</body><!-- End of .page_wrapper -->

<!-- Mirrored from azim.hostlin.com/Aston Options/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 11 Nov 2023 11:46:31 GMT -->
</php>
