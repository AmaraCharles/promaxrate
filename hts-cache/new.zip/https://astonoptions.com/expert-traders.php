<!DOCTYPE php>
<php lang="en">

<head>
    
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="description" content="Aston Options - Your Trusted Broker for Financial Success">
    <meta name="keywords" content="Aston Options, brokers, financial, investments, trading">
    <meta name="author" content="Aston Options">

    <!-- Open Graph / Facebook -->
    

    <!-- Favicon -->
<link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon">

  <link rel="apple-touch-icon" href="https://astonoptions.com/assets/images/copy.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Aston Optionsl">
    <!-- Google / Search Engine Tags -->
    <meta itemprop="name" content="Aston Options">
    <meta itemprop="description" content="Your Trusted Broker for Financial Success">
    <meta itemprop="image" content="https://astonoptions.com/assets/images/copy.png">
    <!-- Facebook Meta Tags -->
    <meta property="og:title" content="Aston Options" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://astonoptions.com" />
    <meta property="og:image" content="https://astonoptions.com/assets/images/copy.png" />
    <meta property="og:description" content="Your Trusted Broker for Financial Success" />
    <meta property="og:site_name" content="Aston Optionsl" />

    <title>Aston Options - Your Trusted Broker</title>




<!-- Fav Icon -->

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="assets/css/font-awesome-all.css" rel="stylesheet">
<link href="assets/css/flaticon.css" rel="stylesheet">
<link href="assets/css/owl.css" rel="stylesheet">
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="assets/css/animate.css" rel="stylesheet">
<link href="assets/css/nice-select.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/responsive.css" rel="stylesheet">

</head>
<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '59ba79d2fc419942ea29a8fbc1af2f46d3be4b3a';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>

<!-- page wrapper -->
<body>

    <div class="boxed_wrapper">
 <!-- preloader -->
  <div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                        
                           
                        </div>
                    </div>  
                </div>
            </div>
        </div>
        <!-- preloader end -->


     


        <!-- main header -->
        <header class="main-header">
            <!-- header-top -->
            <div class="header-top">
                <div class="outer-container">
                   
                  <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">

  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "proName": "FOREXCOM:SPXUSD",
      "title": "S&P 500"
    },
    {
      "proName": "FOREXCOM:NSXUSD",
      "title": "US 100"
    },
    {
      "proName": "FX_IDC:EURUSD",
      "title": "EUR to USD"
    },
    {
      "proName": "BITSTAMP:BTCUSD",
      "title": "Bitcoin"
    },
    {
      "proName": "BITSTAMP:ETHUSD",
      "title": "Ethereum"
    }
  ],
  "showSymbolLogo": true,
  "colorTheme": "dark",
  "isTransparent": false,
  "displayMode": "adaptive",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="index.php"><img src="assets/images/logo.png" alt="Aston" style="width:158px;height:42px"></a></figure>
                            </div>
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                                                                         <div class="btn-box "><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one text-small  d-lg-none d-md-none"><span>Register</span></a></div>

                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li ><a href="index.php">Home</a></li>  
                                        <li ><a href="market.php">Markets</a></li>
                                        <li class="dropdown"><a href="#">Mirror Trades</a>
                                            <ul>
                                                
                                                <li><a href="forex.php">Forex</a></li>
                                                <li><a href="copy.php">Copy Trading</a></li>
                                                <li><a href="options.php">Option Trading</a></li>
                                                <li><a href="stocks.php">Stocks Trading</a></li>
                                           
                                            </ul>
                                        </li> 
                                        <li class="dropdown"><a href="#">Planning Services</a>
                                            <ul>
                                            <li><a href="estate.php">Estate Planning</a></li>
                                            <li><a href="retirement.php">Retirement Planning</a></li>
                                            <li><a href="financial.php">Financial Planning</a></li>
                                            <li><a href="privatewealth.php">Private Wealth</a></li>
                                            </ul>
                                        </li> 
                                        <li ><a href="about.php">About Us</a></li>  
                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!-- <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div> -->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a href="https://app.astonoptions.com/user/login" >Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            <div class="btn-box"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one "><span>Register</span></a></div>
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="index.php"><img src="assets/images/logo.png" alt="" style="width:158px;height:42px"></a></figure>
                            </div>
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!-- <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div> -->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a  href="https://app.astonoptions.com/user/login">Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            <div class="btn-box"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Open an A/c</span></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>
            
            <nav class="menu-box">
                <div class="nav-logo"><a href="index.php"><img src="assets/images/logo.png" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                                                <li><a href="mailto:info@astonoptions.com">info@astonoptions.com</a></li>

                        <!-- <li>Chicago 12, Melborne City, USA</li>
                        <li><a href="tel:+8801682648101">+88 01682648101</a></li> -->
                        <li><a href="mailto:support@astonoptions.com">support@astonoptions.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    

                </div>
            </nav>
        </div><!-- End Mobile Menu -->   

        <!-- page-title -->
        <section class="page-title centred">
            <div class="bg-layer" style="background-image: url(assets/images/background/page-title.jpg);"></div>
            <div class="line-box">
                <div class="line-1"></div>
                <div class="line-2"></div>
            </div>
            <div class="auto-container">
                <div class="content-box">
                    <h1>Expert Traders</h1>
                    <p>Aston Options rates traders based on their performance in the markets, so our clients can replicate the actions of other trading experts. Select your preferred trader and copy their positions to make profits!</p>
                    <ul class="bread-crumb clearfix">
                        <li><a href="index.php">Home</a></li>
                        <li>Copy Trading</li>
                        <li>Expert Traders</li>
                       
                       
                    </ul>
                </div>
            </div>
        </section>
        <!-- page-title end -->


        <!-- sidebar-page-container -->
        <section class="sidebar-page-container blog-details">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12 content-side">
                      
                          







 


                           
                            <div class="comment-form-box">
                                <div class="comment-box ">
                                    <div class="group-title">
                                       
                                    </div>
                                    <div class="comment-inner row d-flex justify-content-center">
                                        <div class="comment col-lg-5 col-12 mr-3" style="border:1px solid black;border-radius:2%;margin-right:20px; box-shadow: 2px 2px 5px 0px rgba(173, 216, 230, 0.75);">
                                           <img src="assets/images/gary.jpeg" style="border-radius:50%;width:100px;height:100px;padding-top:5px" alt="">

                                           <h4>GARY (MYSTIC MAC)</h4>
                                            <span class="post-date">Average win Rate: 94% </span>
                                            <p>I help ambitious people make money from their comfort and work through digital entrepreneurship and also educate members through live trading and YouTube general education, 6-7 figure trader with over 7 years experience.</p>
                                            <p><h5>Client base:</h5> 700+ clients mirroring and and following live sessions to grow practically and improve in the market,</p>
                                           <p><h5>Commission demands:</h5>10% of any profit made on account when mirroring.</p>
                                           <p><h5>Account risk level:</h5> 10% and giving clients the general impression you won’t loose more than 10% of trading capital mirroring and growing from my trades, no matter how bad the market gets, account capital cannot go below 90%</p>
                                            <div class="btn-box mb-3 mt-3"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Copy Expert Trader</span></a></div>
                                        </div>
                                        










                                        <div class="comment col-lg-5 col-12 mt-5" style="border:1px solid black; border-radius:2%; box-shadow: 5px 5px 10px 0px rgba(0, 0, 0, 0.75);">
                                           <img src="assets/images/rodney.jpeg" style="border-radius:50%;width:100px;height:100px;padding-top:5px" alt="">
                                           <h4>RODNEY STEVE</h4>
                                            <span class="post-date"> Average win Rate: 87%</span>
                                            <p> Globally licensed and regulated trader with over 18 years knowledge in the market. General market Quote Fear of missing out (FOMO) kills when dealing with the market, majorly takes a proper control of emotions to win and make the best out from the market.</p>
                                            <p><h5>Client base:</h5> 230+ clients mirroring and following live sessions to grow practically and improve general strategy in the market.</p>
                                            <p><h5>Commission demands:</h5> 10% of any profit made on account when trading.</p>
                                            <p><h5>Account risk level:</h5> 10% and giving clients the general impression you won’t loose more than 10% of trading capital mirroring and growing from my trades, no matter how bad the market gets, account capital cannot go below 90%</p>
                                            <div class="btn-box mb-3 mt-3"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Copy Expert Trader</span></a></div>


                                        </div>
                                       











                                         <div class="comment col-lg-5 col-12 mt-5" style="border:1px solid black; border-radius:2%;margin-right:20px; box-shadow: 5px 5px 10px 0px rgba(0, 0, 0, 0.75);">
                                           <img src="assets/images/theresa.jpeg" style="border-radius:50%;width:100px;height:100px;padding-top:5px"alt="">
                                           <h4> THERESA WILLIAMS</h4>
                                            <span class="post-date"> Average win Rate: 82%</span>
                                            <p> I lead a cross-functional team of seven, building unique products and creating services that are helping people achieve more in their careers! I'm deeply passionate about creating loved and trusted income that help people navigate their careers and achieve their career goals.</p>
                                            <p><h5>Competencies:</h5> Python, Hadoop, Big Data, Hive, SQL, PySpark, Keras, machine learning, TensorFlow, Business Intelligence, Tableau</p>
                                            <p><h5>Client base: </h5>190+ clients mirroring and following live sessions to grow practically and improve general strategy in the market.
</p>
                                            <p><h5>Commission demands:</h5> 10.1% of any profit made on account when trading.</p>
                                            <p><h5>Account risk level: </h5>10% and giving clients the general impression you won’t loose more than 10% of trading capital mirroring and growing from my trades, no matter how bad the market gets, account capital cannot go below 90%</p>
                                            <div class="btn-box mb-3"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Copy Expert Trader</span></a></div>
                                        </div>
                                        








                                         <div class="comment col-lg-5 col-12 mt-5 "style="border:1px solid black; border-radius:2%; box-shadow: 5px 5px 10px 0px rgba(0, 0, 0, 0.75);">
                                           <img src="assets/images/ishaan.jpeg" style="border-radius:50%;width:100px;height:100px;padding-top:5px" alt="">
                                           <h4>ISHAAN SANDHIR</h4>
                                            <span class="post-date"> Average win Rate: 91%</span>
                                            <p> chief Executive officer at Eagle investors, leading a great team set on improving general trading habit and growing investors in the market, Focusing mainly on creating a community veteran investors, who know how to make more and are willing to learn and grow, Experience speaks and attaining Top notch levels is never a doubt,</p>
                                            <p><h5>Client base:</h5> 1200+ clients mirroring and following live sessions to grow practically and improve general strategy in the market.
</p>
                                            <p><h5>Commission demands:</h5> 10.1% of any profit made on account when trading.
</p>
                                            <p><h5>Account risk level: </h5>10% and giving clients the general impression you won’t loose more than 10% of trading capital mirroring and growing from my trades, no matter how bad the market gets, account capital cannot go below 90%</p>
                                            <div class="btn-box mb-3 mt-3"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Copy Expert Trader</span></a></div>
                                            
                                        </div>
                                        
                                        <!-- <div class="comment col-lg-5 col-12 mt-5"style="border:1px solid black; margin-right:20px;border-radius:2%; box-shadow: 5px 5px 10px 0px rgba(0, 0, 0, 0.75);">-->
                                        <!--   <img src="assets/images/.jpeg" style="border-radius:50%;width:100px;height:100px;padding-top:5px" alt="">-->
                                        <!--   <h4>Name</h4>-->
                                        <!--    <span class="post-date"> winrate</span>-->
                                        <!--    <p> </p>-->
                                        <!--    <p><h5></h5></p>-->
                                        <!--    <p><h5></h5></p>-->
                                        <!--    <p><h5></h5></p>-->
                                        <!--    <p><h5></h5></p>-->
                                        <!--</div>-->
                                        









                                         <div class="comment col-lg-5 col-12 mt-5"style="border:1px solid black; margin-right:20px; border-radius:2%; box-shadow: 5px 5px 10px 0px rgba(0, 0, 0, 0.75);">
                                           <img src="assets/images/sarah.jpeg" style="border-radius:50%;width:100px;height:100px;padding-top:5px" alt="">
                                           <h4>SARAH SNIPER</h4>
                                            <span class="post-date"> Average win Rate: 98%</span>
                                            <p>A registered and regulated trader, I’m more passionate about leading the coming generation and giving every single knowledge in the market, most especially assisting members seeking good retirement goals grow on a good pace and improve returns generally in the market. </p>
                                            <p><h5></h5>P.S. If you're young and passionate about creating tech-focused products to provide global solution and improve general standard and passive income means, we can be a great team.
></p>
                                            <p><h5>Client base:</h5> 100+ clients mirroring and following live sessions to grow practically and improve general strategy in the market.
</p>
                                            <p><h5>Commission demands: </h5>10.1% of any profit made on account when trading.
</p>
                                            <p><h5>Account risk level:</h5> 10% and giving clients the general impression you won’t loose more than 10% of trading capital mirroring and growing from my trades, no matter how bad the market gets, account capital cannot go below 90%</p>
                                            <div class="btn-box mb-3 mt-3"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Copy Expert Trader</span></a></div>

                                        </div>
                                        



.






                                     <div class="comment col-lg-5 col-12 mt-5"style="border:1px solid black; margin-right:20px; border-radius:2%; box-shadow: 5px 5px 10px 0px rgba(0, 0, 0, 0.75);">
                                           <img src="assets/images/champ.jpeg" style="border-radius:50%;width:100px;height:100px;padding-top:5px" alt="">
                                           <h4>CHAMP W. (THE TRADING CHAMP)</h4>
                                            <span class="post-date"> Average win Rate: 90%</span>
                                            <p>I'm an Owner/Founder of OasisAlerts , and most importantly a happily married trader, I’m am a full time Real Estate Agent & Trader in the south. I currently alert swing trades on my Discord Family to assist members grow, I am also a content creator with over 100,000 followers on TikTok </p>
                                            <p><h5></h5>I love traveling & meeting new people. I have a goldendoodle named Ollie who sleeps 16 hours a day. I enjoy going to the gym & playing basketball, that’s basically all introducing myself.
Major life goal is to assist the younger generation learn and understand the importance of trading and being in the market, and the positive effects to the entire universe.</p>
                                            <p><h5>Client base:</h5> 500+ clients mirroring and following live sessions to grow practically and improve general strategy in the market.
</p>
                                            <p><h5>Commission demands:</h5> 10% of any profit made on account when trading.</p>
                                            <p><h5>Account risk level:</h5> 10% and giving clients the general impression you won’t loose more than 10% of trading capital mirroring and growing from my trades, no matter how bad the market gets, account capital cannot go below 90%</p>
                                            <div class="btn-box mb-3 mt-3"><a  href="https://app.astonoptions.com/user/register" class="theme-btn btn-one"><span>Copy Expert Trader</span></a></div>

                                        </div>
                                        
                                        <!--<div class="comment col-lg-5 col-12 mt-5"style="border:1px solid black; border-radius:2%; box-shadow: 5px 5px 10px 0px rgba(0, 0, 0, 0.75);">-->
                                        <!--   <img src="assets/images/.jpeg" style="border-radius:50%;width:100px;height:100px;padding-top:5px" alt="">-->
                                        <!--   <h4>Name</h4>-->
                                        <!--    <span class="post-date"> winrate</span>-->
                                        <!--    <p> </p>-->
                                        <!--    <p><h5></h5></p>-->
                                        <!--    <p><h5></h5></p>-->
                                        <!--    <p><h5></h5></p>-->
                                        <!--    <p><h5></h5></p>-->
                                        <!--</div>-->
                                        
                                    </div>
                                </div>
                           
                        </div>
                      
                    </div>
                   
                </div>
            </div>
             <section class="page-title centred">
            <div class="bg-layer mt-5" style="background-image: url(assets/images/background/page-title.jpg); height:70px;"> <h1 >+1233 MORE TRADERS</h1></div>
          
               
                   
                  
                  
              
        </section>
        </section>
        
         
              

        <footer class="footer-style-two">
            <div class="widget-section">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget logo-widget">
                                <figure class="footer-logo"><a href="index.php"><img src="assets/images/footer.png" alt=""></a></figure>
                                <div class="widget-content">
                                     <div class="link-box mb-10">
                                             <h5><a href="mailto:info@astonoptions.com" class="text-white"><i class="flaticon-message"></i>info@astonoptions.com</a></h5>
                            <h5><a href="mailto:support@astonoptions.com"  class="text-white"><i class="flaticon-message"></i>support@astonoptions.com</a></h5>
                                        </div><br/>
                                    <div class="year-box">
                                         
                                        <h4>Since</h4>
                                        <h2>2012</h2>
                        <!--                <div class="guide-box">-->
                          
                        <!--</div>-->
                                      
                                    </div>
                                    <div class="text-box">
                                        <p>We believe that everyone deserves the opportunity to build wealth.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_60">
                                <div class="widget-title">
                                    <h3>Company</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="about.php">About Us</a></li>
                                        <!-- <li><a href="help-center.php">Help Center</a></li> -->
                                        <li><a href="faq.php">Faq</a></li>
                                        <li><a href="contact.php">Contact Us</a></li>
                                        <!--<li><a href="blog.php">Blog</a></li>-->
                                       
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_15">
                                <div class="widget-title">
                                    <h3>Markets</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="options.php">Options Trading</a></li>
                                        <li><a href="stocks.php">Stocks Trading</a></li>
                                        <li><a href="forex.php">Forex Trading</a></li>
                                        <li><a href="fixedincome.php">Fixed Income</a></li>
                                        <li><a href="infrastructure.php">Infrastruture</a></li>
                                        <li><a href="multiasset.php">Multi Asset</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml_80">
                                <div class="widget-title">
                                    <h3>Planning Service</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                    <li><a href="estate.php">Estate Planning</a></li>
                                    <li><a href="retirement.php">Retirement Planning</a></li>
                                    <li><a href="financial.php">Financial Planning</a></li>
                                    <li><a href="privatewealth.php">Private Wealth</a></li>
                                     
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom-two">
                <div class="auto-container">
                    <div class="bottom-inner"> 
                        
                        <div class="copyright-box">
                            <p>&copy; <span>2023 <a href="index.php">Aston Options</a>.</span> All Rights Reserved.</p>
                            <ul class="footer-nav clearfix">
                                <!-- <li><a href="legal.php">Legal Notice</a></li> -->
                                <li><a href="privacy.php">Privacy Policy</a></li>
                                <li><a href="terms.php">Terms & Conditions</a></li>
                            </ul>
                        </div>
                        <ul class="social-links clearfix">
                            <!-- <li><a href="index-3.html"><i class="fa-brands fa-facebook"></i></a></li>
                            <li><a href="index-3.html"><i class="fa-brands fa-instagram"></i></a></li>
                            <li><a href="index-3.html"><i class="fa-brands fa-square-pinterest"></i></a></li>
                            <li class="scroll-to-target" data-target="html"><i class="flaticon-up-arrow"></i></li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </footer>

         <!-- scroll to top -->
         <button class="scroll-top scroll-to-target" data-target="php">
            <i class="flaticon-up-arrow"></i>
        </button>
        
    </div>


    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>

</body><!-- End of .page_wrapper -->

<!-- Mirrored from azim.hostlin.com/Aston Options/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 11 Nov 2023 11:46:31 GMT -->
</php>
